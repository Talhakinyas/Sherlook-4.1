@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Sherlook
where python >nul 2>nul
if errorlevel 1 (
  echo Python bulunamadi. https://www.python.org/downloads/ adresinden kurun
  echo ve kurulumda "Add Python to PATH" kutusunu isaretleyin.
  pause
  exit /b 1
)
echo Gerekli paketler kontrol ediliyor...
python -m pip install -q -r requirements.txt
echo.
echo Sherlock baslatiliyor. Kapatmak icin bu pencereyi kapatin.
python -m sherlock.web
pause
