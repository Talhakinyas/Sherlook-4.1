# Sherlook 🔍

Bir kişinin kullanıcı adını, ad soyadını veya e-postasını kullanarak 111 sitede herkese açık hesaplarını bulan,
profilleri birbiriyle karşılaştırıp **hangisinin gerçekten o kişiye ait olduğunu** puanlayan OSINT aracı.

## Hızlı başlangıç (Windows)

1. [Python](https://www.python.org/downloads/) kurun (kurulumda **"Add Python to PATH"** kutusunu işaretleyin).
2. Bu klasördeki **`baslat.bat`** dosyasına çift tıklayın. Paketler kurulur, tarayıcıda arayüz açılır.
3. Siyah pencere açık kaldığı sürece uygulama çalışır; kapatınca durur.

Python'suz çalışan tek dosya isterseniz **`build_exe.bat`**'a çift tıklayın; `dist\Sherlook.exe` oluşur.
Bu dosyayı istediğiniz bilgisayara kopyalayıp çift tıklayarak açabilirsiniz.

Mac / Linux:

```bash
pip install -r requirements.txt
python -m sherlock.web
```

## Özellikler

| Özellik | Açıklama |
|---|---|
| **Kullanıcı adı araması** | 111 site, 11 kategori (Türkiye sitesi dahil); sonuçlar canlı akar |
| **Ad Soyad kombinasyonları** | "Ahmet Yılmaz" → ahmetyilmaz, ahmet.yilmaz, ayilmaz, ahmetyilmaz95 … (Türkçe karakterler dönüştürülür) |
| **E-posta incelemesi** | Gravatar profili, veri sızıntıları (Have I Been Pwned), adresten olası kullanıcı adları |
| **Profil bilgisi** | Ad, bio, fotoğraf, konum, takipçi, katılım tarihi, profildeki linkler (site API'leri + sayfa meta etiketleri) |
| **Güven puanı** | Her profile %0–100 puan ve gerekçeleri: ad eşleşmesi, aynı fotoğraf, birbirine link verme… |
| **Fotoğraf eşleştirme** | Farklı sitelerde aynı profil fotoğrafını kullanan hesaplar (algısal özet / dHash) |
| **Bağlantılı hesaplar** | Profillerdeki linklerden aranmamış hesapları, kişisel siteleri ve e-postaları çıkarır |
| **İlişki grafiği** | Kişi → kullanıcı adları → profiller → bağlantılar ağı |
| **Vakalar** | Her arama otomatik kaydedilir; aynı arama tekrarlanınca yeni / kaybolan profiller gösterilir; vaka notları |
| **Rapor** | Tek sayfalık HTML rapor, "Yazdır / PDF" ile PDF'e kaydedilebilir |
| **Proxy / Tor** | `socks5h://127.0.0.1:9050` gibi bir proxy üzerinden arama |
| **Site öz testi** | `--self-check` ile her site ayarını doğrular, yanlış sonuç veren siteleri bulur |
| **🌐 Dünya (God's Eye View)** | Canlı uçak, gemi, uydu, deprem ve hava durumu gösteren 3D küre Sherlock'un içinde; bulunan konumlara tek tıkla uçar |

## 🌐 Dünya: God's Eye View entegrasyonu

Sağ üstteki **Dünya** düğmesi, Bilawal Sidhu'nun açık kaynak (MIT)
[God's Eye View](https://github.com/bilawalsidhu/gods-eye-view) projesini Sherlock'un içinde açar:
fotogerçekçi 3D küre üzerinde canlı uçaklar, askerî uçaklar, uydular, gemiler, depremler, yangınlar,
rüzgâr, yağış radarı, kasırgalar, roket fırlatmaları ve deniz altı kabloları.

**Gereken:** [Node.js 24 LTS](https://nodejs.org/en/download) (veya 26). Kurduktan sonra Sherlock'u yeniden açın.

1. **Dünya** → **Kur**: God's Eye View indirilir ve kurulur (bir kez, ~600 MB, birkaç dakika).
2. **Başlat**: God's Eye View arka planda açılır ve sayfada görünür. Sherlock kapanınca o da kapanır.
3. **Keşif** görünümünde Sherlock panelinden konumları, canlı katmanları, görüntü stilini ve haritayı seçin.
   **Tam çalışma alanı** görünümünde God's Eye View'un kendi panelleri, takip, kokpit, sahne ve diğer araçları
   aynı Sherlock ekranının içinde açılır. **Tam ekran** ile çalışma alanını genişletebilirsiniz.
4. Aramada bulunan profillerde konum yazıyorsa **Konumlar** listesinde çıkar; **Git** ile küre oraya uçar.
   Aynısı profil detayındaki ve Bağlantılar sekmesindeki **🌐 Dünyada göster** düğmeleriyle de yapılır.
5. **Yeni pencerede aç**: İsterseniz aynı konumu ayrı pencerede açın.

God's Eye View altyapısı arayüzde **Sherlook** adı ve logosuyla görünür. Dil menüsünde **Türkçe** bulunur;
ana kontroller çevrilmiştir, henüz çevrilmeyen uzmanlık metinleri İngilizceye döner.
Uçak, gemi veya uydu seçildiğinde Sherlook bilgi kartı kimlik, hareket ve mevcut rota bilgisini gösterir.
Gemi izi ve uydu yörüngesi haritada çizilir; uçuş rotası yalnızca doğrulanmış kalkış/varış verisi varsa yazılır.
Uçaklarda önce operatör ve model birlikte, sonuç yoksa kayıt numarası aranır. Firma/model sonucu temsili olarak etiketlenir.
Gemilerde MMSI ile eşleşen Wikimedia Commons görseli bulunursa küçük bir önizleme ve kaynak bağlantısı gösterilir;
aksi halde tür simgesi kullanılır. Uydularda yanlış eşleşmeleri önlemek için yalnızca simge gösterilir.
Seçim bilgisini paylaşan diğer katmanlarda da aynı kart kaynak, konum ve sağlanan özellikleri gösterir.
Bu katmanlar doğrulanmış görsel veya rota sağlamıyorsa kart bunları varmış gibi göstermez.
Haritada **Bu bölgede ne oluyor?** düğmesi, görünüm merkezinin 50/100/250 km çevresinde hava durumu,
son 24 saatteki deprem ve yangınlar, uçaklar, gemiler, kasırgalar ve mevcut uydu geçişleri için kaynaklı bir özet açar.
Ulaşılamayan veri kaynakları ayrı işaretlenir; boş sonuçlar olay yok olarak gösterilir.

Notlar:
- Konumlar **şehir düzeyinde** gösterilir; Türkiye'nin 81 ili ve büyük dünya şehirleri internete sorulmadan
  bulunur, diğerleri OpenStreetMap Nominatim ile aranır. Sokak/adres düzeyine inilmez.
- Sherlock'un **Keşif** panelinde kamera ve plaka okuyucu katmanları bulunmaz. **Tam çalışma alanı**
  God's Eye View'un kendi arayüzünü gösterir; bu araçlar uygulamanın kendi kontrollerinde bulunabilir.
- Fotogerçekçi 3D şehirler için God's Eye View'a Cesium ion veya Google Maps anahtarı eklemeniz gerekir
  (tam sürümde **POWER UP** paneli). Anahtarsız da uydu görüntüsüyle çalışır.
- God's Eye View, gömülmeye yalnızca `?embed=1` modunda ve yalnızca Sherlock'un adresine izin verir;
  diğer sayfaları korumalı kalır. Kendiniz ayrıca başlattığınız bir God's Eye View gömülemez, Sherlock'tan başlatın.
- Kurulum klasörü: `~/.sherlock/gods-eye-view` (`GEV_DIR` ile değiştirilebilir). Port: 4173 (`GEV_PORT`).
  Başka bir bilgisayarda çalışan God's Eye View için `GEV_URL` kullanılabilir.
- **Güncelle**, API anahtarlarınızı (`.env`) ve önbelleği koruyarak en son sürümü kurar.
- God's Eye View'un tam arayüzü Sherlock Atlas temasıyla yeniden düzenlenir. Tema kaynağı
  `sherlock/static/gev-theme.css` içindedir; kurulum ve **Güncelle** sonrasında yeniden uygulanır.

God's Eye View ayrı bir projedir ve ilk kurulumda resmî deposundan indirilir. Kaynak kodu bu depoya
eklenmez. Telif hakkı ve MIT lisansı [kendi deposunda](https://github.com/bilawalsidhu/gods-eye-view/blob/main/LICENSE)
yer alır; bu deponun `LICENSE` dosyası Sherlook kaynakları içindir.

## Komut satırı

```bash
python -m sherlock kullaniciadi                      # tek kullanıcı adı
python -m sherlock ali veli -v                       # birden çok, tüm sonuçlarla
python -m sherlock -n "Ahmet Yılmaz" --year 1995     # ad soyad kombinasyonları + güven puanı
python -m sherlock torvalds -V                       # varyasyonlar (realtorvalds, torvalds_official…)
python -m sherlock -e ahmet@gmail.com --email-search # e-posta incele + çıkan adlarla ara
python -m sherlock ali -o html                       # results/ali.html raporu (txt/json/csv/html)
python -m sherlock ali -s GitHub -s Reddit           # sadece belirli siteler
python -m sherlock ali --proxy socks5h://127.0.0.1:9050
python -m sherlock --self-check                      # site ayarlarını test et
python -m sherlock --list-sites
```

Sızıntı kontrolü için [HIBP API anahtarı](https://haveibeenpwned.com/API/Key) gerekir:
`--hibp-key ANAHTAR` veya `HIBP_API_KEY` ortam değişkeni (web arayüzünde E-posta sekmesindeki alan).

Çıktı simgeleri: `[+]` bulundu · `[-]` yok · `[!]` kullanıcı adı sitenin kurallarına uymuyor ·
`[?]` kontrol edilemedi (bot koruması, hız sınırı, ağ hatası).

## Güven puanı nasıl hesaplanır?

| Durum | Puan |
|---|---|
| Kullanıcı adı sitede kayıtlı | +20 |
| Profil bilgisi okunabildi | +5 |
| Profildeki ad aranan adla tam / kısmen eşleşiyor | +35 / +15 |
| Profildeki ad tamamen farklı | −15 |
| Başka sitedeki profille aynı fotoğraf | +25 |
| Başka bir bulunan profil bu hesaba link veriyor | +25 |
| Bu profil başka bir bulunan hesaba link veriyor | +10 |
| En olası kullanıcı adı | +5 |
| 4 karakter veya daha kısa kullanıcı adı | −10 |

Puan bir tahmindir; kesin kimlik tespiti değildir. Yüksek puanlı sonuçları da profili açıp kontrol edin.

## Vakalar ve veriler

Aramalar `~/.sherlock/sherlock.db` (Windows'ta `C:\Users\<ad>\.sherlock\sherlock.db`) dosyasında saklanır.
Başka bir konum için `SHERLOCK_DATA` ortam değişkenini ayarlayın. Kaydetmemek için CLI'da `--no-save` kullanın.

## Site ekleme

`sherlock/sites.json` dosyasına bir giriş ekleyin:

```json
"SiteAdı": {
  "url": "https://site.com/{}",
  "probeUrl": "https://api.site.com/users/{}",
  "errorType": "status_code",
  "errorMsg": "User not found",
  "errorUrl": "https://site.com/",
  "regexCheck": "^[a-z0-9_]+$",
  "cat": "Sosyal",
  "known": "var_olan_bir_kullanici"
}
```

- `url`: kullanıcıya gösterilen profil adresi (`{}` yerine kullanıcı adı gelir)
- `probeUrl` (isteğe bağlı): asıl isteğin atılacağı adres, genelde sitenin API'si
- `errorType`: `status_code` (404 = yok), `message` (sayfada `errorMsg` varsa yok) veya `response_url` (`errorUrl`'e yönlenirse yok)
- `known`: `--self-check` için var olduğu bilinen bir kullanıcı adı

Ekledikten sonra `python -m sherlock --self-check -s SiteAdı` ile test edin.

## Testler

```bash
python -m unittest discover tests
```

## Yasal uyarı

Bu araç yalnızca herkese açık bilgileri sorgular; giriş gerektiren, gizli veya özel içeriğe erişmez.
Eğitim, güvenlik araştırması, kendi dijital ayak izinizi kontrol etme ve yetkili soruşturmalar için kullanın.
Kişileri izlemek, taciz etmek veya ifşa etmek için kullanmayın. KVKK/GDPR ve sitelerin kullanım koşullarına
uymak kullanıcının sorumluluğundadır.
