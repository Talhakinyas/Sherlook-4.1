@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Sherlook - exe olusturuluyor
echo Gerekli paketler kuruluyor...
python -m pip install -q -r requirements.txt pyinstaller
if errorlevel 1 goto hata
echo Sherlook.exe olusturuluyor (birkac dakika surebilir)...
python -m PyInstaller --noconfirm --onefile --name Sherlook ^
  --add-data "sherlock/static;sherlock/static" ^
  --add-data "sherlock/sites.json;sherlock" ^
  sherlock_app.py
if errorlevel 1 goto hata
echo.
echo Tamam! Dosya: dist\Sherlook.exe
echo Bu dosyayi istediginiz yere kopyalayip cift tiklayarak acabilirsiniz.
pause
exit /b 0
:hata
echo.
echo Bir hata olustu. Yukaridaki mesaji kontrol edin.
pause
exit /b 1
