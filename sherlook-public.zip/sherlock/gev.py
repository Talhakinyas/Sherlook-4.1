"""God's Eye View (https://github.com/bilawalsidhu/gods-eye-view) entegrasyonu.

God's Eye View ayrı bir Node.js uygulamasıdır; Sherlock onu indirir, kurar, arka planda
başlatır ve web arayüzündeki "Dünya" sayfasında gösterir. Sherlock kapanınca o da kapanır.

Ortam değişkenleri:
  GEV_DIR   kurulum klasörü (varsayılan: <veri klasörü>/gods-eye-view)
  GEV_PORT  God's Eye View'un portu (varsayılan 4173)
  GEV_URL   başka yerde çalışan bir God's Eye View kullan (kurulum/başlatma devre dışı)
"""

from __future__ import annotations

import atexit
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from collections import deque
from pathlib import Path, PurePosixPath

import requests

from .storage import data_dir

REPO_URL = "https://github.com/bilawalsidhu/gods-eye-view"
ZIP_URL = "https://codeload.github.com/bilawalsidhu/gods-eye-view/zip/refs/heads/main"
NODE_URL = "https://nodejs.org/en/download"
# package.json "engines": ">=24.14.0 <25 || >=26 <27"
NODE_OK = lambda v: (v[0] == 24 and v[1:] >= (14, 0)) or v[0] == 26
# Güncellemede korunacak kullanıcı verileri (API anahtarları, önbellek, kayıtlar)
KEEP_ON_UPDATE = (".env", ".gev-cache", ".gev-logs")
MAX_ZIP = 300_000_000


def enable_workspace_mode(directory: Path) -> bool:
    """Expose native controls and install Sherlock's update-safe GEV theme."""
    script = directory / "src" / "app" / "embed.js"
    css = directory / "src" / "ui" / "styles" / "embed.css"
    theme = directory / "src" / "ui" / "styles" / "sherlock-theme.css"
    theme_source = Path(__file__).with_name("static") / "gev-theme.css"
    entry = directory / "style.css"
    if not script.is_file() or not css.is_file() or not entry.is_file() or not theme_source.is_file():
        return False
    source = script.read_text(encoding="utf-8")
    styles = css.read_text(encoding="utf-8")
    marker = "const workspace = new URLSearchParams(location?.search || '').get('sherlock_workspace') === '1';"
    if marker not in source:
        old = "  windowRef.document.body.classList.add('ui-embed');\n  shell.setCleanView?.(true);"
        new = ("  " + marker + "\n"
               "  windowRef.document.body.classList.add('ui-embed');\n"
               "  if (workspace) windowRef.document.body.classList.add('ui-sherlock-workspace');\n"
               "  shell.setCleanView?.(!workspace);")
        if old not in source:
            return False
        source = source.replace(old, new, 1)
    if "body.ui-embed:not(.ui-sherlock-workspace)" not in styles:
        if "body.ui-embed #clean-view-exit" not in styles:
            return False
        styles = styles.replace("body.ui-embed #", "body.ui-embed:not(.ui-sherlock-workspace) #")
    if source != script.read_text(encoding="utf-8"):
        script.write_text(source, encoding="utf-8")
    if styles != css.read_text(encoding="utf-8"):
        css.write_text(styles, encoding="utf-8")
    theme_text = theme_source.read_text(encoding="utf-8")
    if not theme.is_file() or theme.read_text(encoding="utf-8") != theme_text:
        theme.write_text(theme_text, encoding="utf-8")
    import_line = "@import './src/ui/styles/sherlock-theme.css';"
    entry_text = entry.read_text(encoding="utf-8")
    if import_line not in entry_text:
        entry.write_text(entry_text.rstrip() + "\n" + import_line + "\n", encoding="utf-8")
    return apply_sherlook_brand(directory) if (directory / "index.html").is_file() else True


def _replace_compat(path: Path, before: str, after: str) -> bool:
    text = path.read_text(encoding="utf-8")
    if after in text:
        return True
    if before not in text:
        return False
    path.write_text(text.replace(before, after, 1), encoding="utf-8")
    return True


def apply_sherlook_brand(directory: Path) -> bool:
    """Install the Sherlock name, icon and Turkish catalog after GEV updates."""
    assets = Path(__file__).with_name("static")
    logo_source = assets / "gev-logo.svg"
    tr_source = assets / "gev-tr.json"
    if not logo_source.is_file() or not tr_source.is_file():
        return False
    replacements = (
        ("index.html", "<title>God's Eye View</title>", "<title>Sherlook</title>"),
        ("index.html", 'content="God\'s Eye"', 'content="Sherlook"'),
        ("index.html", 'GOD\'S EYE <span class="title-accent">VIEW</span>', '<span class="title-accent">SHERLOOK</span>'),
        ("src/ui/views/SceneChromeView.vue", 'GOD\'S EYE <span class="title-accent">VIEW</span>', '<span class="title-accent">SHERLOOK</span>'),
        ("src/i18n/locale.js", "  'ru',\n  'uk',", "  'ru',\n  'tr',\n  'uk',"),
        ("src/i18n/locale.js", "  ru: 'Русский',\n  uk:", "  ru: 'Русский',\n  tr: 'Türkçe',\n  uk:"),
        ("src/i18n/index.js", "import ru from './locales/ru.json' with { type: 'json' };", "import ru from './locales/ru.json' with { type: 'json' };\nimport tr from './locales/tr.json' with { type: 'json' };"),
        ("src/i18n/index.js", "  ru,\n  uk,", "  ru,\n  tr,\n  uk,"),
        ("src/ui/localePicker.test.mjs", "      'pt',\n      'ar',", "      'pt',\n      'tr',\n      'ar',"),
        ("src/ui/localePicker.test.mjs", "      'pt',\n      'ru',", "      'pt',\n      'tr',\n      'ru',"),
    )
    for relative, before, after in replacements:
        target = directory / relative
        if not target.is_file() or not _replace_compat(target, before, after):
            return False
    manifest_path = directory / "public" / "manifest.webmanifest"
    if not manifest_path.is_file():
        return False
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest.update(name="Sherlook", short_name="Sherlook",
                    description="Sherlook canlı dünya keşif arayüzü.",
                    background_color="#0b1119", theme_color="#0b1119")
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    logo = directory / "public" / "logo.svg"
    changed = not logo.is_file() or logo.read_bytes() != logo_source.read_bytes()
    if changed:
        logo.write_bytes(logo_source.read_bytes())
        node = shutil.which("node")
        if node:
            try:
                result = subprocess.run([node, "scripts/generate-icons.mjs"], cwd=directory,
                                        capture_output=True, text=True, timeout=60)
                if result.returncode:
                    return False
            except (OSError, subprocess.SubprocessError):
                return False
    tr = directory / "src" / "i18n" / "locales" / "tr.json"
    if not tr.is_file() or tr.read_bytes() != tr_source.read_bytes():
        tr.write_bytes(tr_source.read_bytes())
    inspector_source = assets / "gev-inspector.js"
    if not inspector_source.is_file():
        return False
    inspector = directory / "public" / "sherlook-inspector.js"
    if not inspector.is_file() or inspector.read_bytes() != inspector_source.read_bytes():
        inspector.write_bytes(inspector_source.read_bytes())
    index_path = directory / "index.html"
    index_text = index_path.read_text(encoding="utf-8")
    inspector_tag = '<script defer src="/sherlook-inspector.js"></script>'
    if inspector_tag not in index_text:
        index_path.write_text(index_text.replace("</body>", f"  {inspector_tag}\n</body>", 1), encoding="utf-8")
    region_source = assets / "gev-region.js"
    if not region_source.is_file():
        return False
    region = directory / "src" / "sherlookRegion.js"
    if not region.is_file() or region.read_bytes() != region_source.read_bytes():
        region.write_bytes(region_source.read_bytes())
    index_text = index_path.read_text(encoding="utf-8")
    region_tag = '<script type="module" src="/src/sherlookRegion.js"></script>'
    if region_tag not in index_text:
        index_path.write_text(index_text.replace("</body>", f"  {region_tag}\n</body>", 1), encoding="utf-8")
    return True


IS_WIN = sys.platform == "win32"


def _local() -> requests.Session:
    s = requests.Session()
    s.trust_env = False  # 127.0.0.1 kontrolleri sistem proxy'sinden geçmesin
    return s


def _safe_extract(zf: zipfile.ZipFile, dest: Path) -> None:
    """Zip içeriğini, klasör dışına yazmaya çalışan girdileri reddederek çıkarır."""
    root = dest.resolve()
    for m in zf.infolist():
        p = PurePosixPath(m.filename)
        if p.is_absolute() or ".." in p.parts:
            raise ValueError(f"Güvensiz zip girdisi: {m.filename}")
        target = (root / Path(*p.parts)).resolve()
        if root != target and root not in target.parents:
            raise ValueError(f"Güvensiz zip girdisi: {m.filename}")
    zf.extractall(root)


class GodsEyeView:
    def __init__(self) -> None:
        self.external_url = (os.environ.get("GEV_URL") or "").rstrip("/") or None
        self.port = int(os.environ.get("GEV_PORT") or 4173)
        self.proc: subprocess.Popen | None = None
        self.phase = "idle"  # idle | installing | starting | error
        self.error: str | None = None
        self.log: deque[str] = deque(maxlen=200)
        # Gömme modunda (?embed=1) God's Eye View'u çerçeveleyebilecek sayfa(lar): Sherlock'un adresi
        self.frame_ancestors = "http://127.0.0.1:5000 http://localhost:5000"
        self._lock = threading.Lock()
        atexit.register(self.stop)

    # ---------- bilgi ----------

    @property
    def dir(self) -> Path:
        return Path(os.environ.get("GEV_DIR") or data_dir() / "gods-eye-view")

    @property
    def url(self) -> str:
        return self.external_url or f"http://127.0.0.1:{self.port}"

    def node(self) -> dict:
        path = shutil.which("node")
        info = {"path": path, "version": None, "ok": False, "npm": bool(shutil.which("npm"))}
        if path:
            try:
                out = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=10).stdout
                m = re.match(r"v(\d+)\.(\d+)\.(\d+)", out.strip())
                if m:
                    v = tuple(int(x) for x in m.groups())
                    info.update(version=".".join(map(str, v)), ok=NODE_OK(v))
            except (OSError, subprocess.SubprocessError):
                pass
        return info

    def installed(self) -> bool:
        return (self.dir / "package.json").exists() and (self.dir / "node_modules" / "vite").exists()

    def workspace_ready(self) -> bool:
        if self.external_url:
            return False
        script = self.dir / "src" / "app" / "embed.js"
        css = self.dir / "src" / "ui" / "styles" / "embed.css"
        return (script.is_file() and css.is_file()
                and "sherlock_workspace" in script.read_text(encoding="utf-8")
                and "ui-sherlock-workspace" in css.read_text(encoding="utf-8"))

    def running(self) -> bool:
        try:
            r = _local().get(self.url + "/", timeout=1.5)
            return r.ok and "<html" in r.text[:2000].lower()
        except requests.RequestException:
            return False

    def status(self) -> dict:
        running = self.running()
        if running and self.phase == "starting":
            self.phase = "idle"
        if self.proc and self.proc.poll() is not None and self.phase == "starting":
            self.phase, self.error = "error", "God's Eye View başlarken kapandı; ayrıntılar kayıtta."
        return {
            "url": self.url, "external": bool(self.external_url), "running": running,
            "installed": bool(self.external_url) or self.installed(), "managed": self.proc is not None,
            "workspace_ready": self.workspace_ready(),
            "phase": self.phase, "error": self.error, "dir": str(self.dir), "node": self.node(),
            "log": list(self.log)[-40:], "repo": REPO_URL, "node_url": NODE_URL,
        }

    # ---------- kurulum / güncelleme ----------

    def install(self) -> None:
        with self._lock:
            if self.phase in ("installing", "starting"):
                return
            if self.external_url:
                raise RuntimeError("GEV_URL ayarlıyken kurulum yapılmaz.")
            node = self.node()
            if not node["ok"] or not node["npm"]:
                raise RuntimeError("Node.js 24 (LTS) veya 26 gerekli. " + NODE_URL)
            self.phase, self.error = "installing", None
            self.log.clear()
        threading.Thread(target=self._install, daemon=True).start()

    def _say(self, msg: str) -> None:
        self.log.append(msg.rstrip())

    def _fetch_source(self, staging: Path) -> None:
        """Kaynak kodu staging/<tek klasör> içine indirir: önce zip, olmazsa git clone."""
        self._say("God's Eye View indiriliyor…")
        try:
            r = requests.get(ZIP_URL, timeout=60, stream=True)
            r.raise_for_status()
            buf = io.BytesIO()
            for chunk in r.iter_content(1 << 20):
                buf.write(chunk)
                if buf.tell() > MAX_ZIP:
                    raise RuntimeError("İndirilen dosya beklenenden büyük.")
        except (requests.RequestException, RuntimeError) as exc:
            git = shutil.which("git")
            if not git:
                raise RuntimeError(f"İndirilemedi ({exc}). İnternet bağlantınızı kontrol edin.") from exc
            self._say(f"Zip indirilemedi ({type(exc).__name__}); git ile deneniyor…")
            p = subprocess.run([git, "clone", "--depth", "1", REPO_URL, str(staging / "gods-eye-view")],
                               capture_output=True, text=True, timeout=900,
                               env={**os.environ, "GIT_LFS_SKIP_SMUDGE": "1", "GIT_TERMINAL_PROMPT": "0"})
            if p.returncode != 0:
                raise RuntimeError("git clone başarısız: " + (p.stderr.strip().splitlines() or ["?"])[-1]) from exc
            shutil.rmtree(staging / "gods-eye-view" / ".git", ignore_errors=True)
            self._say("İndirildi (git).")
            return
        self._say(f"İndirildi ({buf.tell() // 1_000_000} MB). Açılıyor…")
        with zipfile.ZipFile(buf) as zf:
            _safe_extract(zf, staging)

    def _install(self) -> None:
        was_running = self.proc is not None
        try:
            parent = self.dir.parent
            parent.mkdir(parents=True, exist_ok=True)
            staging = parent / (self.dir.name + ".yeni")
            shutil.rmtree(staging, ignore_errors=True)
            staging.mkdir()
            self._fetch_source(staging)
            tops = [p for p in staging.iterdir() if p.is_dir()]
            if len(tops) != 1 or not (tops[0] / "package.json").exists():
                raise RuntimeError("İndirilen arşiv beklenen yapıda değil.")
            new = tops[0]

            if self.dir.exists():
                self.stop()
                for name in KEEP_ON_UPDATE:
                    if (self.dir / name).exists():
                        shutil.move(str(self.dir / name), str(new / name))
                old = parent / (self.dir.name + ".eski")
                shutil.rmtree(old, ignore_errors=True)
                self.dir.rename(old)
                shutil.rmtree(old, ignore_errors=True)
            shutil.move(str(new), str(self.dir))
            shutil.rmtree(staging, ignore_errors=True)

            self._say("Bağımlılıklar kuruluyor (npm ci, birkaç dakika sürebilir)…")
            npm = shutil.which("npm")
            cmd = ["cmd", "/c", npm, "ci", "--no-audit", "--no-fund"] if IS_WIN else [npm, "ci", "--no-audit", "--no-fund"]
            p = subprocess.Popen(cmd, cwd=self.dir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, encoding="utf-8", errors="replace")
            for line in p.stdout:
                if line.strip():
                    self._say(line)
            if p.wait() != 0:
                raise RuntimeError(f"npm ci başarısız oldu (çıkış kodu {p.returncode}).")
            if not enable_workspace_mode(self.dir):
                self._say("Tam çalışma alanı bu sürümle uyumlu değil; küre modu kullanılabilir.")
            self._say("Kurulum tamamlandı.")
            self.phase = "idle"
            if was_running:
                self.start()
        except Exception as exc:  # kullanıcıya kayıtta göster
            self.phase, self.error = "error", str(exc)
            self._say(f"HATA: {exc}")

    # ---------- başlat / durdur ----------

    def start(self) -> None:
        with self._lock:
            if self.external_url or self.running():
                return
            if self.phase == "installing":
                raise RuntimeError("Kurulum sürüyor.")
            if not self.installed():
                raise RuntimeError("God's Eye View kurulu değil.")
            node = self.node()
            if not node["ok"]:
                raise RuntimeError(f"Node.js {node['version'] or 'bulunamadı'}; 24 (LTS) veya 26 gerekli.")
            if not enable_workspace_mode(self.dir):
                self._say("Tam çalışma alanı bu sürümle uyumlu değil; küre modu kullanılabilir.")
            vite = self.dir / "node_modules" / "vite" / "bin" / "vite.js"
            env = {**os.environ, "HOST": "127.0.0.1", "PORT": str(self.port),
                   "GEV_EMBED_FRAME_ANCESTORS": self.frame_ancestors}
            self.phase, self.error = "starting", None
            self._say(f"Başlatılıyor: {self.url}")
            self.proc = subprocess.Popen(
                [node["path"], str(vite), "--port", str(self.port), "--strictPort", "--host", "127.0.0.1"],
                cwd=self.dir, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace")
        threading.Thread(target=self._pump, args=(self.proc,), daemon=True).start()

    def _pump(self, proc: subprocess.Popen) -> None:
        ansi = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
        for line in proc.stdout:
            if line.strip():
                self._say(ansi.sub("", line))

    def stop(self) -> None:
        p, self.proc = self.proc, None
        if p and p.poll() is None:
            p.terminate()
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill()
        if self.phase == "starting":
            self.phase = "idle"


manager = GodsEyeView()
