"""Sherlock çekirdeği: bir kullanıcı adını birçok sitede paralel olarak kontrol eder."""

from __future__ import annotations

import json
import re
import secrets
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from enum import Enum
from pathlib import Path
from typing import Iterator

import requests

SITES_FILE = Path(__file__).with_name("sites.json")
USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)
PROXY_RE = re.compile(r"^(https?|socks5h?)://[^\s/]+(:\d+)?/?$")

# Bot koruması sayfaları 200 döndüğü için "bulundu" sanılmamalı.
CHALLENGE_MARKERS = (
    "<title>Client Challenge",
    "<title>Just a moment...",
    "<title>Attention Required! | Cloudflare",
    "cf-browser-verification",
    "challenge-platform",
    "<title>DDoS-Guard",
)


def is_challenge(text: str) -> bool:
    head = text[:5000]
    return any(m in head for m in CHALLENGE_MARKERS)


class Status(str, Enum):
    FOUND = "bulundu"
    NOT_FOUND = "yok"
    ILLEGAL = "geçersiz"
    ERROR = "hata"


@dataclass
class Result:
    site: str
    username: str
    url: str
    status: Status
    http_status: int | None = None
    elapsed_ms: int | None = None
    error: str | None = None
    profile: dict | None = field(default=None)

    @property
    def key(self) -> str:
        return f"{self.site}|{self.username}"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["status"] = self.status.value
        return d


def load_sites(path: Path | str = SITES_FILE) -> dict[str, dict]:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def make_session(workers: int = 20, proxy: str | None = None) -> requests.Session:
    if proxy and not PROXY_RE.match(proxy):
        raise ValueError("Proxy biçimi geçersiz. Örnek: socks5h://127.0.0.1:9050")
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"})
    adapter = requests.adapters.HTTPAdapter(pool_connections=workers, pool_maxsize=workers)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    if proxy:
        session.proxies = {"http": proxy, "https": proxy}
    return session


def check_site(
    session: requests.Session,
    site: str,
    info: dict,
    username: str,
    timeout: float,
    enrich: bool = False,
) -> Result:
    url = info["url"].format(username)
    regex = info.get("regexCheck")
    if regex and not re.search(regex, username):
        return Result(site, username, url, Status.ILLEGAL)

    probe = info.get("probeUrl", info["url"]).format(username)
    error_type = info["errorType"]
    start = time.monotonic()
    try:
        resp = session.get(probe, timeout=timeout, allow_redirects=True)
    except requests.RequestException as exc:
        return Result(site, username, url, Status.ERROR, error=type(exc).__name__)
    elapsed = int((time.monotonic() - start) * 1000)

    if error_type == "status_code":
        found = 200 <= resp.status_code < 300 and resp.status_code != 204  # 204: boş yanıt
    elif error_type == "message":
        found = resp.ok and info["errorMsg"] not in resp.text
    elif error_type == "response_url":
        found = resp.ok and resp.url.rstrip("/") != info["errorUrl"].rstrip("/")
    else:
        return Result(site, username, url, Status.ERROR, error=f"bilinmeyen errorType: {error_type}")

    if found and is_challenge(resp.text):
        return Result(site, username, url, Status.ERROR, resp.status_code, elapsed,
                      error="bot koruması")

    # 403/429/5xx genelde bot koruması demektir; "yok" demek yanıltıcı olur.
    if not found and (resp.status_code in (403, 429) or resp.status_code >= 500):
        return Result(site, username, url, Status.ERROR, resp.status_code, elapsed,
                      error="engellendi / hız sınırı")

    result = Result(site, username, url, Status.FOUND if found else Status.NOT_FOUND,
                    resp.status_code, elapsed)
    if found and enrich:
        from .profile import extract  # döngüsel içe aktarmayı önle
        try:
            result.profile = extract(session, site, info, username, url, resp, timeout)
        except Exception:  # profil bilgisi isteğe bağlıdır; aramayı bozmasın
            result.profile = None
    return result


def search(
    username: str,
    sites: dict[str, dict],
    timeout: float = 10.0,
    workers: int = 20,
    proxy: str | None = None,
    enrich: bool = False,
) -> Iterator[Result]:
    """Sonuçları geldikleri sırayla üretir."""
    return search_many([username], sites, timeout, workers, proxy, enrich)


def search_many(
    usernames: list[str],
    sites: dict[str, dict],
    timeout: float = 10.0,
    workers: int = 20,
    proxy: str | None = None,
    enrich: bool = False,
) -> Iterator[Result]:
    """Birden çok kullanıcı adını tek havuzda tarar; sonuçları geldikleri sırayla üretir.

    İşler kullanıcı adı sırasıyla kuyruğa girer, böylece aynı anda çalışan istekler
    farklı sitelere dağılır ve tek bir siteye yük bindirilmez.
    """
    session = make_session(workers, proxy)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [
            pool.submit(check_site, session, name, info, username, timeout, enrich)
            for username in usernames
            for name, info in sites.items()
        ]
        try:
            for fut in as_completed(futures):
                yield fut.result()
        finally:
            # Tüketici erken durursa (ör. tarayıcıda "Durdur") bekleyen işleri iptal et.
            for f in futures:
                f.cancel()


@dataclass
class CheckReport:
    site: str
    verdict: str  # "tamam", "yanlış pozitif", "yanlış negatif", "hata", "bilinen ad yok"
    known: str | None
    known_status: str | None
    random_status: str
    note: str = ""


def self_check(
    sites: dict[str, dict],
    timeout: float = 10.0,
    workers: int = 20,
    proxy: str | None = None,
) -> Iterator[CheckReport]:
    """Her siteyi bilinen bir kullanıcı adı ve rastgele bir adla deneyip ayarı doğrular."""
    session = make_session(workers, proxy)
    fake = "zz" + secrets.token_hex(6)

    def one(name: str, info: dict) -> CheckReport:
        rnd = check_site(session, name, info, fake, timeout)
        known = info.get("known")
        kn = check_site(session, name, info, known, timeout) if known else None
        if rnd.status is Status.ERROR or (kn and kn.status is Status.ERROR):
            err = rnd.error if rnd.status is Status.ERROR else kn.error
            verdict, note = "hata", err or ""
        elif rnd.status is Status.FOUND:
            verdict, note = "yanlış pozitif", "var olmayan bir ad 'bulundu' çıktı"
        elif kn is None:
            verdict, note = "bilinen ad yok", "sites.json'a \"known\" ekleyin"
        elif kn.status is not Status.FOUND:
            verdict, note = "yanlış negatif", "bilinen ad bulunamadı (ad değişmiş de olabilir)"
        else:
            verdict, note = "tamam", ""
        return CheckReport(name, verdict, known, kn.status.value if kn else None,
                           rnd.status.value, note)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        for fut in as_completed([pool.submit(one, n, i) for n, i in sites.items()]):
            yield fut.result()
