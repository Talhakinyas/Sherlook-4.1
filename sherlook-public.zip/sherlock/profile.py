"""Bulunan profillerden herkese açık bilgileri çeker.

Herkese açık JSON API'si olan sitelerde API kullanılır; diğerlerinde sayfanın
OpenGraph / meta etiketleri okunur. Ayrıca profil fotoğrafının algısal özeti
(dHash) hesaplanır, böylece farklı sitelerdeki aynı fotoğraf eşleştirilebilir.
"""

from __future__ import annotations

import html
import io
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Any, Callable
from urllib.parse import urljoin, urlparse

import requests

MAX_HTML = 1_500_000
MAX_IMAGE = 3_000_000
URL_RE = re.compile(r"https?://[^\s<>\"')\]]+")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


# ---------- yardımcılar ----------

def clean(text: Any, limit: int = 600) -> str | None:
    """HTML etiketlerini ve fazla boşlukları temizler."""
    if text is None:
        return None
    s = html.unescape(re.sub(r"<br\s*/?>|</p>", "\n", str(text)))
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n\s*\n+", "\n", s).strip()
    return s[:limit] or None


def iso(ts: Any) -> str | None:
    """Unix zaman damgası (sn/ms) veya ISO metnini YYYY-AA-GG biçimine çevirir."""
    if ts in (None, "", 0):
        return None
    try:
        if isinstance(ts, (int, float)) or str(ts).isdigit():
            v = float(ts)
            if v > 1e11:
                v /= 1000
            return datetime.fromtimestamp(v, tz=timezone.utc).strftime("%Y-%m-%d")
        return str(ts)[:10]
    except (ValueError, OSError):
        return None


def links_in(*texts: Any) -> list[str]:
    out: list[str] = []
    for t in texts:
        if t:
            out += [u.rstrip(".,;") for u in URL_RE.findall(html.unescape(str(t)))]
    return out


def with_scheme(u: str | None) -> str | None:
    if not u:
        return None
    u = u.strip()
    return u if u.startswith(("http://", "https://")) else f"https://{u}"


# ---------- site özel çıkarıcılar (herkese açık JSON API'ler) ----------

Extractor = Callable[[Any], dict]
API: dict[str, tuple[str, Extractor]] = {}


def api(site: str, url: str):
    def deco(fn: Extractor) -> Extractor:
        API[site] = (url, fn)
        return fn
    return deco


@api("GitHub", "https://api.github.com/users/{}")
def _github(d):
    return {
        "name": d.get("name"), "bio": d.get("bio"), "avatar": d.get("avatar_url"),
        "location": d.get("location"), "followers": d.get("followers"),
        "created": iso(d.get("created_at")),
        "links": [with_scheme(d.get("blog")),
                  f"https://x.com/{d['twitter_username']}" if d.get("twitter_username") else None],
        "extra": {"Şirket": d.get("company"), "Açık repo": d.get("public_repos"),
                  "E-posta": d.get("email")},
    }


@api("GitLab", "https://gitlab.com/api/v4/users?username={}")
def _gitlab(d):
    d = d[0] if isinstance(d, list) and d else {}
    return {"name": d.get("name"), "avatar": d.get("avatar_url")}


@api("Reddit", "https://www.reddit.com/user/{}/about.json")
def _reddit(d):
    d = d.get("data", {})
    sub = d.get("subreddit") or {}
    return {
        "name": sub.get("title") or d.get("name"), "bio": sub.get("public_description"),
        "avatar": html.unescape(d.get("icon_img") or "") or None,
        "created": iso(d.get("created_utc")),
        "extra": {"Karma": d.get("total_karma")},
    }


@api("Chess.com", "https://api.chess.com/pub/player/{}")
def _chesscom(d):
    return {"name": d.get("name"), "avatar": d.get("avatar"), "location": d.get("location"),
            "followers": d.get("followers"), "created": iso(d.get("joined")),
            "extra": {"Ünvan": d.get("title"), "Durum": d.get("status")}}


@api("Lichess", "https://lichess.org/api/user/{}")
def _lichess(d):
    p = d.get("profile") or {}
    name = p.get("realName") or " ".join(x for x in (p.get("firstName"), p.get("lastName")) if x)
    return {"name": name or None, "bio": p.get("bio"), "location": p.get("location"),
            "created": iso(d.get("createdAt")), "links": links_in(p.get("links")),
            "extra": {"Ülke": p.get("flag") or p.get("country"), "Oyun sayısı": (d.get("count") or {}).get("all")}}


@api("Docker Hub", "https://hub.docker.com/v2/users/{}/")
def _dockerhub(d):
    return {"name": d.get("full_name"), "location": d.get("location"),
            "avatar": d.get("gravatar_url"), "created": iso(d.get("date_joined")),
            "links": [with_scheme(d.get("profile_url"))], "extra": {"Şirket": d.get("company")}}


@api("Mastodon (mastodon.social)", "https://mastodon.social/api/v1/accounts/lookup?acct={}")
def _mastodon(d):
    return {"name": d.get("display_name"), "bio": d.get("note"), "avatar": d.get("avatar"),
            "followers": d.get("followers_count"), "created": iso(d.get("created_at")),
            "links": links_in(*[f.get("value") for f in d.get("fields") or []])}


@api("Bluesky", "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor={}.bsky.social")
def _bluesky(d):
    return {"name": d.get("displayName"), "bio": d.get("description"), "avatar": d.get("avatar"),
            "followers": d.get("followersCount"), "created": iso(d.get("createdAt")),
            "links": links_in(d.get("description"))}


@api("Gravatar", "https://en.gravatar.com/{}.json")
def _gravatar(d):
    e = (d.get("entry") or [{}])[0]
    loc = e.get("currentLocation")
    return {"name": e.get("displayName") or (e.get("name") or {}).get("formatted"),
            "bio": e.get("aboutMe"), "avatar": e.get("thumbnailUrl"), "location": loc,
            "links": [u.get("value") for u in e.get("urls") or []]
                     + [a.get("url") for a in e.get("accounts") or []]}


@api("Keybase", "https://keybase.io/_/api/1.0/user/lookup.json?usernames={}")
def _keybase(d):
    them = (d.get("them") or [None])[0] or {}
    p = them.get("profile") or {}
    proofs = ((them.get("proofs_summary") or {}).get("all")) or []
    return {"name": p.get("full_name"), "bio": p.get("bio"), "location": p.get("location"),
            "avatar": (((them.get("pictures") or {}).get("primary")) or {}).get("url"),
            "links": [x.get("service_url") for x in proofs]}


@api("Hacker News", "https://hacker-news.firebaseio.com/v0/user/{}.json")
def _hn(d):
    d = d or {}
    return {"bio": d.get("about"), "created": iso(d.get("created")),
            "links": links_in(d.get("about")), "extra": {"Karma": d.get("karma")}}


@api("DEV Community", "https://dev.to/api/users/by_username?url={}")
def _dev(d):
    return {"name": d.get("name"), "bio": d.get("summary"), "avatar": d.get("profile_image"),
            "location": d.get("location"), "created": iso(d.get("joined_at")),
            "links": [with_scheme(d.get("website_url")),
                      f"https://github.com/{d['github_username']}" if d.get("github_username") else None,
                      f"https://x.com/{d['twitter_username']}" if d.get("twitter_username") else None]}


@api("Duolingo", "https://www.duolingo.com/2017-06-30/users?username={}")
def _duolingo(d):
    u = (d.get("users") or [{}])[0]
    pic = u.get("picture")
    return {"name": u.get("name"), "avatar": f"https:{pic}/xlarge" if pic and pic.startswith("//") else pic,
            "created": iso(u.get("creationDate")),
            "extra": {"Seri": u.get("streak"), "Toplam XP": u.get("totalXp")}}


# ---------- genel HTML çıkarıcı ----------

class _MetaParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.meta: dict[str, str] = {}
        self.links: list[str] = []
        self.title = ""
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "meta":
            key = (a.get("property") or a.get("name") or "").lower()
            if key and "content" in a and key not in self.meta:
                self.meta[key] = a["content"]
        elif tag == "a" and a.get("href", "").startswith(("http://", "https://")):
            if len(self.links) < 400:
                self.links.append(a["href"])
        elif tag == "title":
            self._in_title = True

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title and len(self.title) < 300:
            self.title += data


def from_html(text: str, base: str) -> dict:
    p = _MetaParser()
    try:
        p.feed(text[:MAX_HTML])
    except Exception:
        pass
    m = p.meta
    img = m.get("og:image") or m.get("twitter:image")
    host = urlparse(base).hostname or ""
    root = ".".join(host.split(".")[-2:])
    external = [u for u in p.links if root not in (urlparse(u).hostname or "")]
    desc = m.get("og:description") or m.get("description") or m.get("twitter:description")
    return {
        "name": m.get("og:title") or m.get("twitter:title") or clean(p.title, 120),
        "bio": desc,
        "avatar": urljoin(base, img) if img else None,
        "links": links_in(desc),
        "page_links": external[:200],
    }


# ---------- fotoğraf özeti ----------

def avatar_hash(session: requests.Session, url: str, timeout: float) -> str | None:
    """64 bit fark özeti (dHash). Pillow yoksa veya resim indirilemezse None."""
    try:
        from PIL import Image
    except ImportError:
        return None
    try:
        r = session.get(url, timeout=timeout, stream=True)
        if not r.ok or "image" not in r.headers.get("Content-Type", "image"):
            return None
        data = r.raw.read(MAX_IMAGE + 1, decode_content=True)
        if len(data) > MAX_IMAGE:
            return None
        img = Image.open(io.BytesIO(data)).convert("L").resize((9, 8), Image.LANCZOS)
        px = list(img.getdata())
    except Exception:
        return None
    bits = 0
    for row in range(8):
        for col in range(8):
            bits = (bits << 1) | (px[row * 9 + col] > px[row * 9 + col + 1])
    # Tek renkli (boş/varsayılan) resimler her şeyle eşleşmesin.
    if bits in (0, (1 << 64) - 1):
        return None
    return f"{bits:016x}"


def hamming(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


# ---------- ana fonksiyon ----------

def extract(
    session: requests.Session,
    site: str,
    info: dict,
    username: str,
    url: str,
    probe_resp: requests.Response,
    timeout: float,
) -> dict | None:
    data: dict = {}
    source = None
    if site in API:
        api_url, fn = API[site]
        api_url = api_url.format(username)
        resp = probe_resp if probe_resp.url.split("#")[0] == api_url else session.get(api_url, timeout=timeout)
        if resp.ok:
            try:
                data = fn(resp.json()) or {}
                source = "api"
            except ValueError:
                data = {}
    if not source:
        resp = probe_resp if probe_resp.url.rstrip("/") == url.rstrip("/") else session.get(url, timeout=timeout)
        if resp.ok and "html" in resp.headers.get("Content-Type", "html"):
            data = from_html(resp.text, resp.url)
            source = "html"
    if not source:
        return None

    bio = clean(data.get("bio"))
    links = [with_scheme(u) for u in (data.get("links") or []) if u]
    links += [u for u in links_in(data.get("bio")) if u not in links]
    extra = {k: v for k, v in (data.get("extra") or {}).items() if v not in (None, "", [])}
    emails = sorted(set(EMAIL_RE.findall(" ".join(filter(None, [bio, str(extra.get("E-posta") or "")])))))
    profile = {
        "source": source,
        "name": clean(data.get("name"), 120),
        "bio": bio,
        "avatar": data.get("avatar") or None,
        "location": clean(data.get("location"), 120),
        "followers": data.get("followers"),
        "created": data.get("created"),
        "links": list(dict.fromkeys(u for u in links if u))[:30],
        "page_links": data.get("page_links") or [],
        "emails": emails,
        "extra": extra,
        "avatar_hash": None,
    }
    if profile["avatar"]:
        profile["avatar_hash"] = avatar_hash(session, profile["avatar"], timeout)
    # Sadece site adını tekrarlayan genel başlıkları at ("Instagram", "GitHub" vb.)
    if profile["name"] and profile["name"].strip().lower() in (site.lower(), username.lower()):
        profile["name"] = None
    shown = ("name", "bio", "avatar", "location", "followers", "created", "links", "extra")
    if not any(profile[k] for k in shown) and not profile["page_links"]:
        return None
    return profile
