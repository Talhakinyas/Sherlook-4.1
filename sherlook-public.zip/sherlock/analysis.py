"""Bulunan profilleri birbiriyle karşılaştırır.

- Güven puanı: profilin aranan kişiye ait olma olasılığı (0-100) ve gerekçeleri
- Fotoğraf eşleştirme: farklı sitelerde benzer profil fotoğrafı kullananlar
- Bağlantılı hesaplar: profillerdeki linklerden bulunan (aranmamış) diğer hesaplar
"""

from __future__ import annotations

import re
from urllib.parse import unquote, urlparse

from .profile import hamming
from .variants import normalize

AVATAR_MAX_DISTANCE = 10  # 64 bitlik dHash'te 10 bit fark ≈ aynı resim
DOMAIN_ALIASES = {"twitter.com": "x.com", "mobile.twitter.com": "x.com", "m.youtube.com": "youtube.com",
                  "old.reddit.com": "reddit.com", "m.twitch.tv": "twitch.tv", "m.facebook.com": "facebook.com"}
# Profil linki olarak anlamsız olan yollar (giriş, yardım vb.)
RESERVED = {"login", "signup", "register", "about", "help", "privacy", "terms", "settings", "explore",
            "search", "home", "share", "intent", "hashtag", "i", "p", "watch", "legal", "download",
            "pricing", "features", "blog", "jobs", "careers", "contact", "support", "policies"}


def _host(u: str) -> str:
    h = (urlparse(u).hostname or "").lower()
    h = h[4:] if h.startswith("www.") else h
    return DOMAIN_ALIASES.get(h, h)


def site_patterns(sites: dict[str, dict]) -> list[tuple[str, str, re.Pattern]]:
    """Her site için 'bu URL hangi kullanıcıya ait' düzenli ifadesi."""
    pats = []
    for name, info in sites.items():
        u = info["url"]
        if "{}" not in u:
            continue
        p = urlparse(u.replace("{}", "USERNAME"))
        host = _host(u.replace("{}", "x"))
        if "USERNAME" in (p.hostname or ""):
            # alt alan adı biçimi (ör. {}.example.com)
            rx = r"^" + re.escape((p.hostname or "").replace("www.", "")).replace("USERNAME", r"([A-Za-z0-9_.-]+)") + r"$"
            pats.append((name, "sub", re.compile(rx, re.I)))
            continue
        path = re.escape(p.path).replace("USERNAME", r"([^/?#]+)")
        query = re.escape(p.query).replace("USERNAME", r"([^&#]+)") if p.query else ""
        rx = rf"^{path}/?$" if not query else rf"^{path}\?{query}"
        pats.append((name, host, re.compile(rx, re.I)))
    return pats


def match_profile_url(url: str, patterns) -> tuple[str, str] | None:
    """URL bilinen bir sitenin profil adresiyse (site, kullanıcı adı) döndürür."""
    try:
        p = urlparse(url)
    except ValueError:
        return None
    host = _host(url)
    for name, phost, rx in patterns:
        if phost == "sub":
            m = rx.match(host)
        elif phost == host:
            target = p.path + (f"?{p.query}" if p.query and "\\?" in rx.pattern else "")
            m = rx.match(target)
        else:
            continue
        if m:
            user = unquote(m.group(1)).lstrip("@")
            if user and user.lower() not in RESERVED:
                return name, user
    return None


def _norm_url(u: str) -> str:
    p = urlparse(u)
    return (_host(u) + p.path.rstrip("/")).lower()


def analyze(results: list[dict], sites: dict[str, dict], context: dict | None = None) -> dict:
    """`results`: Result.to_dict() listesi. `context`: {"name": "Ad Soyad", "usernames": [...]}"""
    context = context or {}
    found = [r for r in results if r["status"] == "bulundu"]
    key = lambda r: f"{r['site']}|{r['username']}"
    by_url = {_norm_url(r["url"]): key(r) for r in found}
    patterns = site_patterns(sites)
    target_tokens = set(normalize(context.get("name") or "").split())
    searched = [u.lower() for u in context.get("usernames") or []]

    # --- fotoğraf kümeleri (farklı sitelerde benzer avatar) ---
    hashed = [(key(r), r["site"], r["profile"]["avatar_hash"]) for r in found
              if r.get("profile") and r["profile"].get("avatar_hash")]
    parent = {k: k for k, _, _ in hashed}

    def root(k):
        while parent[k] != k:
            parent[k] = parent[parent[k]]
            k = parent[k]
        return k

    for i, (ka, sa, ha) in enumerate(hashed):
        for kb, sb, hb in hashed[i + 1:]:
            if sa != sb and hamming(ha, hb) <= AVATAR_MAX_DISTANCE:
                parent[root(ka)] = root(kb)
    groups: dict[str, list[str]] = {}
    for k, _, _ in hashed:
        groups.setdefault(root(k), []).append(k)
    avatar_groups = [g for g in groups.values() if len(g) > 1]
    in_group = {k for g in avatar_groups for k in g}

    # --- profiller arası linkler ve yeni keşifler ---
    edges: list[dict] = []          # bulunan profil -> bulunan profil
    discovered: dict[str, dict] = {}  # aranmamış ama linklerden çıkan hesaplar
    websites: dict[str, dict] = {}    # bilinen site olmayan kişisel linkler
    linked_to: dict[str, set] = {}
    emails: dict[str, set] = {}
    locations: dict[str, dict] = {}
    for r in found:
        prof = r.get("profile") or {}
        k = key(r)
        for e in prof.get("emails") or []:
            emails.setdefault(e.lower(), set()).add(k)
        if prof.get("location"):
            loc = locations.setdefault(normalize(prof["location"]) or prof["location"].lower(),
                                       {"text": prof["location"], "via": []})
            loc["via"].append(k)
        explicit = prof.get("links") or []
        for u in list(dict.fromkeys(explicit + (prof.get("page_links") or []))):
            target = by_url.get(_norm_url(u))
            if target and target != k:
                edges.append({"from": k, "to": target, "url": u})
                linked_to.setdefault(target, set()).add(k)
                continue
            m = match_profile_url(u, patterns)
            if m:
                s, user = m
                tk = f"{s}|{user}"
                if tk in by_url.values() or tk == k:
                    if tk != k:
                        edges.append({"from": k, "to": tk, "url": u})
                        linked_to.setdefault(tk, set()).add(k)
                    continue
                if s == r["site"]:
                    continue  # aynı sitedeki başka hesaplar (takip edilenler vb.) kişiye ait değil
                d = discovered.setdefault(tk, {"site": s, "username": user, "url": sites[s]["url"].format(user),
                                               "via": []})
                if k not in d["via"]:
                    d["via"].append(k)
            elif u in explicit:
                w = websites.setdefault(_norm_url(u), {"url": u, "via": []})
                if k not in w["via"]:
                    w["via"].append(k)

    # --- güven puanı ---
    scores: dict[str, dict] = {}
    for r in found:
        k = key(r)
        prof = r.get("profile") or {}
        score, why = 20, ["Kullanıcı adı bu sitede kayıtlı"]
        if prof:
            score += 5
            why.append("Profil bilgileri okunabildi")
        pname = set(normalize(prof.get("name") or "").split())
        if target_tokens and pname:
            common = target_tokens & pname
            if common == target_tokens:
                score += 35
                why.append(f"Profildeki ad aranan adla eşleşiyor ({prof['name']})")
            elif common:
                score += 15
                why.append(f"Profildeki ad kısmen eşleşiyor ({prof['name']})")
            else:
                score -= 15
                why.append(f"Profildeki ad farklı ({prof['name']})")
        if k in in_group:
            score += 25
            why.append("Başka sitelerdeki profil fotoğrafıyla aynı")
        if k in linked_to:
            score += 25
            why.append("Başka bir bulunan profil bu hesaba link veriyor")
        if any(e["from"] == k for e in edges):
            score += 10
            why.append("Bu profil başka bir bulunan hesaba link veriyor")
        if searched and r["username"].lower() == searched[0]:
            score += 5
            why.append("En olası kullanıcı adı")
        if len(r["username"]) <= 4:
            score -= 10
            why.append("Çok kısa kullanıcı adı; başkasına ait olabilir")
        scores[k] = {"score": max(0, min(100, score)), "reasons": why}

    return {
        "scores": scores,
        "avatar_groups": avatar_groups,
        "edges": edges,
        "discovered": sorted(discovered.values(), key=lambda d: -len(d["via"])),
        "websites": list(websites.values()),
        "emails": [{"email": e, "via": sorted(v)} for e, v in sorted(emails.items())],
        "locations": sorted(locations.values(), key=lambda x: -len(x["via"])),
    }


def diff(previous: list[dict], current: list[dict]) -> dict:
    """İki tarama arasında bulunan profil farkı."""
    k = lambda r: f"{r['site']}|{r['username']}"
    before = {k(r) for r in previous if r["status"] == "bulundu"}
    now = {k(r) for r in current if r["status"] == "bulundu"}
    # Bu sefer kontrol edilemeyen siteleri 'kayboldu' sayma.
    unknown = {k(r) for r in current if r["status"] == "hata"}
    return {"new": sorted(now - before), "gone": sorted(before - now - unknown)}
