"""E-posta adresi araması.

- Gravatar: adrese bağlı herkese açık profil/fotoğraf var mı
- Have I Been Pwned: adres bilinen veri sızıntılarında geçiyor mu (API anahtarı gerekir:
  https://haveibeenpwned.com/API/Key)
- Adresin @ öncesinden olası kullanıcı adları
"""

from __future__ import annotations

import hashlib
import re

import requests

from .profile import clean, links_in

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
FREE_PROVIDERS = {"gmail.com", "googlemail.com", "hotmail.com", "outlook.com", "live.com", "yahoo.com",
                  "icloud.com", "me.com", "yandex.com", "yandex.com.tr", "protonmail.com", "proton.me",
                  "mail.ru", "gmx.com", "aol.com", "msn.com", "hotmail.com.tr", "windowslive.com"}


def suggest_usernames(email: str) -> list[str]:
    local = email.split("@", 1)[0].lower().split("+", 1)[0]
    out = [local]
    out.append(re.sub(r"[._-]", "", local))
    out.append(re.sub(r"\d+$", "", local))
    out.append(re.sub(r"\d+$", "", re.sub(r"[._-]", "", local)))
    for sep in ("_", ".", "-"):
        out.append(re.sub(r"[._-]", sep, local))
    return [u for u in dict.fromkeys(out) if len(u) >= 3]


def gravatar(session: requests.Session, email: str, timeout: float) -> dict | None:
    md5 = hashlib.md5(email.strip().lower().encode()).hexdigest()
    avatar = f"https://www.gravatar.com/avatar/{md5}?s=200&d=404"
    profile: dict = {"hash": md5, "avatar": None, "url": None}
    try:
        if session.get(avatar, timeout=timeout).status_code == 200:
            profile["avatar"] = avatar
        r = session.get(f"https://en.gravatar.com/{md5}.json", timeout=timeout)
        if r.ok:
            e = (r.json().get("entry") or [{}])[0]
            profile.update({
                "url": e.get("profileUrl"),
                "username": e.get("preferredUsername"),
                "name": clean(e.get("displayName") or (e.get("name") or {}).get("formatted"), 120),
                "bio": clean(e.get("aboutMe")),
                "location": clean(e.get("currentLocation"), 120),
                "links": [u.get("value") for u in e.get("urls") or []]
                         + [a.get("url") for a in e.get("accounts") or []] + links_in(e.get("aboutMe")),
            })
    except (requests.RequestException, ValueError):
        return {"error": "Gravatar'a ulaşılamadı"}
    return profile if profile["avatar"] or profile["url"] else None


def breaches(session: requests.Session, email: str, api_key: str, timeout: float) -> dict:
    try:
        r = session.get(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{requests.utils.quote(email)}",
            params={"truncateResponse": "false"},
            headers={"hibp-api-key": api_key, "user-agent": "sherlock-osint"},
            timeout=timeout,
        )
    except requests.RequestException as exc:
        return {"error": f"HIBP'ye ulaşılamadı ({type(exc).__name__})"}
    if r.status_code == 404:
        return {"items": []}
    if r.status_code == 401:
        return {"error": "HIBP API anahtarı geçersiz"}
    if r.status_code == 429:
        return {"error": "HIBP hız sınırı; biraz sonra tekrar deneyin"}
    if not r.ok:
        return {"error": f"HIBP hatası (HTTP {r.status_code})"}
    items = [{
        "name": b.get("Title") or b.get("Name"),
        "domain": b.get("Domain"),
        "date": b.get("BreachDate"),
        "data": b.get("DataClasses") or [],
        "verified": b.get("IsVerified"),
    } for b in r.json()]
    return {"items": sorted(items, key=lambda b: b["date"] or "", reverse=True)}


def lookup(session: requests.Session, email: str, hibp_key: str | None = None, timeout: float = 10) -> dict:
    email = email.strip()
    if not EMAIL_RE.match(email):
        return {"email": email, "valid": False}
    domain = email.split("@", 1)[1].lower()
    return {
        "email": email,
        "valid": True,
        "domain": domain,
        "free_provider": domain in FREE_PROVIDERS,
        "gravatar": gravatar(session, email, timeout),
        "breaches": breaches(session, email, hibp_key, timeout) if hibp_key else None,
        "suggested_usernames": suggest_usernames(email),
    }
