"""Sherlock komut satırı arayüzü."""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

from . import __version__, storage
from .analysis import analyze
from .core import Result, Status, load_sites, make_session, search_many, self_check
from .emailcheck import lookup
from .report import render
from .variants import generate

BANNER = r"""
   _____ __              __           __
  / ___// /_  ___  _____/ /___  _____/ /__
  \__ \/ __ \/ _ \/ ___/ / __ \/ ___/ //_/
 ___/ / / / /  __/ /  / / /_/ / /__/ ,<
/____/_/ /_/\___/_/  /_/\____/\___/_/|_|   v{}
  Kullanıcı adı OSINT aracı
"""

USE_COLOR = sys.stdout.isatty()
COLORS = {
    Status.FOUND: "\033[92m",
    Status.NOT_FOUND: "\033[90m",
    Status.ILLEGAL: "\033[93m",
    Status.ERROR: "\033[91m",
}
SYMBOLS = {Status.FOUND: "+", Status.NOT_FOUND: "-", Status.ILLEGAL: "!", Status.ERROR: "?"}
DIM, BOLD, RESET = ("\033[2m", "\033[1m", "\033[0m") if USE_COLOR else ("", "", "")


def paint(text: str, status: Status) -> str:
    return f"{COLORS[status]}{text}{RESET}" if USE_COLOR else text


def print_result(r: Result, verbose: bool, show_user: bool = False) -> None:
    label = f"{r.site} (@{r.username})" if show_user else r.site
    if r.status is Status.FOUND:
        line = paint(f"[{SYMBOLS[r.status]}] {label}: {r.url}", r.status)
        p = r.profile or {}
        info = " · ".join(str(x) for x in (p.get("name"), p.get("location")) if x)
        print(line + (f"  {DIM}{info}{RESET}" if info else ""))
    elif verbose:
        extra = f" ({r.error})" if r.error else ""
        print(paint(f"[{SYMBOLS[r.status]}] {label}: {r.status.value}{extra}", r.status))


def write_output(results: list[dict], run: dict, label: str, fmt: str, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{label}.{fmt}"
    if fmt == "txt":
        found = [r["url"] for r in results if r["status"] == "bulundu"]
        path.write_text("\n".join(found) + ("\n" if found else ""), encoding="utf-8")
    elif fmt == "json":
        path.write_text(json.dumps({"results": results, "analysis": run["analysis"]},
                                   ensure_ascii=False, indent=2), encoding="utf-8")
    elif fmt == "csv":
        cols = ["site", "username", "url", "status", "score", "name", "location", "bio",
                "http_status", "elapsed_ms", "error"]
        scores = run["analysis"]["scores"]
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            for r in results:
                p = r.get("profile") or {}
                w.writerow({**r, "score": scores.get(f"{r['site']}|{r['username']}", {}).get("score", ""),
                            "name": p.get("name"), "location": p.get("location"), "bio": p.get("bio")})
    elif fmt == "html":
        path.write_text(render(run), encoding="utf-8")
    return path


def safe_label(text: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in text.lower()).strip("_")[:60] or "sonuc"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="sherlock",
        description="Bir kullanıcı adının hangi sitelerde kayıtlı olduğunu bulur.",
    )
    p.add_argument("usernames", nargs="*", help="Aranacak kullanıcı ad(lar)ı")
    g = p.add_argument_group("kombinasyonlar")
    g.add_argument("-n", "--name", help='Ad soyaddan kombinasyon üret, örn. "Ahmet Yılmaz"')
    g.add_argument("--nick", help="Takma ad (kombinasyonlara eklenir)")
    g.add_argument("--year", help="Doğum yılı, örn. 1995 (1995 ve 95 eklenir)")
    g.add_argument("--extra", action="append", default=[], help="Ek sayı, örn. 34 (tekrarlanabilir)")
    g.add_argument("-V", "--variants", action="store_true",
                   help="Verilen kullanıcı adlarının varyasyonlarını da dene (the…, …official, …01)")
    g.add_argument("--max-variants", type=int, default=40, help="En fazla kaç kombinasyon (varsayılan 40)")
    g.add_argument("--show-variants", action="store_true", help="Kombinasyonları sadece listele, arama yapma")
    e = p.add_argument_group("e-posta")
    e.add_argument("-e", "--email", help="E-posta adresini incele (Gravatar, sızıntılar, olası kullanıcı adları)")
    e.add_argument("--hibp-key", default=os.environ.get("HIBP_API_KEY"),
                   help="Have I Been Pwned API anahtarı (veya HIBP_API_KEY ortam değişkeni)")
    e.add_argument("--email-search", action="store_true",
                   help="E-postadan çıkan kullanıcı adlarını sitelerde de ara")
    p.add_argument("-s", "--site", action="append", help="Sadece bu site(ler)de ara (tekrarlanabilir)")
    p.add_argument("-t", "--timeout", type=float, default=10, help="İstek zaman aşımı, sn (varsayılan 10)")
    p.add_argument("-w", "--workers", type=int, default=20, help="Paralel istek sayısı (varsayılan 20)")
    p.add_argument("-v", "--verbose", action="store_true", help="Bulunamayan/hatalı siteleri de göster")
    p.add_argument("-o", "--output", choices=["txt", "json", "csv", "html"], help="Sonuçları dosyaya yaz")
    p.add_argument("--out-dir", type=Path, default=Path("results"), help="Çıktı klasörü (varsayılan ./results)")
    p.add_argument("--proxy", help="Örn. socks5h://127.0.0.1:9050 (Tor) veya http://host:port")
    p.add_argument("--no-profile", action="store_true", help="Profil bilgilerini çekme (daha hızlı)")
    p.add_argument("--no-save", action="store_true", help="Taramayı vaka geçmişine kaydetme")
    p.add_argument("--sites-file", type=Path, help="Özel site listesi (JSON)")
    p.add_argument("--list-sites", action="store_true", help="Desteklenen siteleri listele ve çık")
    p.add_argument("--self-check", action="store_true",
                   help="Her site ayarını bilinen ve rastgele bir adla test et (bozuk siteleri bulur)")
    p.add_argument("--no-banner", action="store_true")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    args = p.parse_args(sys.argv[1:] if argv is None else argv)

    sites = load_sites(args.sites_file) if args.sites_file else load_sites()
    if args.list_sites:
        for name in sorted(sites, key=str.lower):
            print(f"{name:<32} {DIM}{sites[name].get('cat', '')}{RESET}")
        print(f"\nToplam: {len(sites)} site")
        return 0

    if args.site:
        wanted = {s.lower() for s in args.site}
        sites = {k: v for k, v in sites.items() if k.lower() in wanted}
        if not sites:
            p.error("Belirtilen site(ler) listede yok. --list-sites ile bakın.")

    try:
        make_session(1, args.proxy)
    except ValueError as exc:
        p.error(str(exc))

    if args.self_check:
        return run_self_check(sites, args)

    email_info = None
    if args.email:
        email_info = lookup(make_session(4, args.proxy), args.email, args.hibp_key, args.timeout)
        print_email(email_info)
        if not email_info.get("valid"):
            return 1
        if not (args.email_search or args.usernames or args.name):
            return 0

    if args.name:
        usernames = generate(args.name, args.nick, args.year, args.extra, limit=args.max_variants)
        usernames += [u for u in args.usernames if u not in usernames]
    elif args.variants:
        usernames = list(dict.fromkeys(
            v for u in args.usernames
            for v in generate(u, args.nick, args.year, args.extra, limit=args.max_variants)))
    else:
        usernames = list(args.usernames)
    if email_info and args.email_search:
        usernames += [u for u in email_info["suggested_usernames"] if u not in usernames]
    if not usernames:
        p.error("Bir kullanıcı adı, --name ya da --email verin.")

    if args.show_variants:
        print("\n".join(usernames))
        print(f"\nToplam: {len(usernames)} kombinasyon")
        return 0

    if not args.no_banner:
        print(BANNER.format(__version__))
    return run_search(usernames, sites, args)


def run_search(usernames: list[str], sites: dict, args: argparse.Namespace) -> int:
    multi = len(usernames) > 1
    if multi:
        print(f"[*] {len(usernames)} kullanıcı adı × {len(sites)} site = {len(usernames) * len(sites)} sorgu")
        print("[*] " + ", ".join(usernames) + "\n")
    else:
        print(f"[*] '{usernames[0]}' için {len(sites)} sitede aranıyor...\n")

    results: list[Result] = []
    try:
        for r in search_many(usernames, sites, args.timeout, args.workers, args.proxy,
                             enrich=not args.no_profile):
            results.append(r)
            print_result(r, args.verbose, show_user=multi)
    except KeyboardInterrupt:
        print("\n[!] İptal edildi.")
        return 130

    order = {u: i for i, u in enumerate(usernames)}
    results.sort(key=lambda r: (order[r.username], r.site.lower()))
    rows = [r.to_dict() for r in results]
    params = {"usernames": usernames, "name": args.name, "email": args.email}
    analysis = analyze(rows, sites, {"name": args.name, "usernames": usernames})
    run = {"title": args.name or args.email or ", ".join(usernames[:3]), "created": time.time(),
           "params": params, "results": rows, "analysis": analysis, "diff": None}

    found = [r for r in rows if r["status"] == "bulundu"]
    errors = sum(r["status"] == "hata" for r in rows)
    print(f"\n[*] Sonuç: {len(found)} profil bulundu, {errors} sorgu kontrol edilemedi.")

    scores = analysis["scores"]
    top = sorted(found, key=lambda r: -scores[f"{r['site']}|{r['username']}"]["score"])[:10]
    if top and (args.name or analysis["avatar_groups"] or analysis["edges"]):
        print(f"\n{BOLD}En güvenilir eşleşmeler{RESET}")
        for r in top:
            s = scores[f"{r['site']}|{r['username']}"]
            print(f"    %{s['score']:<3} {r['site']:<22} @{r['username']:<24} {DIM}{s['reasons'][-1]}{RESET}")
    if analysis["discovered"]:
        print(f"\n{BOLD}Profillerden bulunan bağlantılı hesaplar{RESET}")
        for d in analysis["discovered"]:
            print(f"    {d['site']:<22} {d['url']}  {DIM}← {', '.join(v.split('|')[0] for v in d['via'])}{RESET}")
    for w in analysis["websites"][:10]:
        print(f"    web sitesi: {w['url']}")
    for em in analysis["emails"]:
        print(f"    e-posta: {em['email']}")

    if not args.no_save:
        try:
            saved = storage.save_run(params, rows, analysis)
            run["diff"] = saved["diff"]
            d = saved["diff"]
            if d and (d["new"] or d["gone"]):
                print(f"\n{BOLD}Önceki taramaya göre{RESET}: {len(d['new'])} yeni, {len(d['gone'])} kaybolan profil")
                for k in d["new"]:
                    print(f"    + {k.replace('|', ' @')}")
                for k in d["gone"]:
                    print(f"    - {k.replace('|', ' @')}")
            print(f"{DIM}[*] Vaka geçmişine kaydedildi ({storage.db_path()}){RESET}")
        except OSError as exc:
            print(f"[!] Geçmişe kaydedilemedi: {exc}")

    if args.output:
        label = safe_label(args.name or args.email or "_".join(usernames[:3]))
        path = write_output(rows, run, label, args.output, args.out_dir)
        print(f"[*] Kaydedildi: {path}")
    return 0


def print_email(info: dict) -> None:
    print(f"{BOLD}E-posta: {info['email']}{RESET}")
    if not info.get("valid"):
        print("    [!] Geçerli bir e-posta adresi değil.")
        return
    print(f"    Alan adı: {info['domain']}" + (" (ücretsiz e-posta servisi)" if info["free_provider"] else ""))
    g = info.get("gravatar")
    if g and not g.get("error"):
        print(f"    Gravatar: {g.get('url') or g.get('avatar')}")
        for k, label in (("name", "Ad"), ("location", "Konum"), ("bio", "Hakkında")):
            if g.get(k):
                print(f"      {label}: {g[k]}")
        for u in g.get("links") or []:
            print(f"      link: {u}")
    elif g:
        print(f"    Gravatar: {g['error']}")
    else:
        print("    Gravatar: kayıt yok")
    b = info.get("breaches")
    if b is None:
        print(f"    Sızıntılar: {DIM}kontrol edilmedi (--hibp-key gerekir){RESET}")
    elif b.get("error"):
        print(f"    Sızıntılar: {b['error']}")
    elif not b["items"]:
        print("    Sızıntılar: bilinen sızıntıda geçmiyor")
    else:
        print(f"    Sızıntılar: {len(b['items'])} sızıntıda geçiyor")
        for x in b["items"]:
            print(f"      {x['date'] or '?':<10} {x['name']:<28} {DIM}{', '.join(x['data'][:5])}{RESET}")
    print(f"    Olası kullanıcı adları: {', '.join(info['suggested_usernames'])}\n")


def run_self_check(sites: dict, args: argparse.Namespace) -> int:
    print(f"[*] {len(sites)} site test ediliyor (bilinen ad + rastgele ad)...\n")
    reports = sorted(self_check(sites, args.timeout, args.workers, args.proxy), key=lambda r: r.site.lower())
    marks = {"tamam": Status.FOUND, "yanlış pozitif": Status.ERROR, "yanlış negatif": Status.ILLEGAL,
             "hata": Status.NOT_FOUND, "bilinen ad yok": Status.NOT_FOUND}
    for r in reports:
        print(paint(f"  {r.verdict:<15} {r.site:<30} {r.note}", marks[r.verdict]))
    counts: dict[str, int] = {}
    for r in reports:
        counts[r.verdict] = counts.get(r.verdict, 0) + 1
    print("\n[*] " + ", ".join(f"{v}: {n}" for v, n in counts.items()))
    print("[*] 'yanlış pozitif' çıkan siteler güvenilmezdir; sites.json'dan kaldırmayı veya düzeltmeyi düşünün.")
    if args.output == "json":
        args.out_dir.mkdir(parents=True, exist_ok=True)
        path = args.out_dir / "self_check.json"
        path.write_text(json.dumps([r.__dict__ for r in reports], ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[*] Kaydedildi: {path}")
    return 1 if counts.get("yanlış pozitif") else 0


if __name__ == "__main__":
    sys.exit(main())
