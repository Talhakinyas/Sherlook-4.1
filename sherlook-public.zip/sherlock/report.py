"""Tek dosyalık, yazdırılabilir (PDF'e kaydedilebilir) HTML rapor üretir."""

from __future__ import annotations

import time
from html import escape

from . import __version__


def _e(v) -> str:
    return escape(str(v)) if v not in (None, "") else ""


def _score_class(s: int) -> str:
    return "hi" if s >= 70 else "mid" if s >= 40 else "lo"


def render(run: dict) -> str:
    results = run.get("results") or []
    a = run.get("analysis") or {}
    scores = a.get("scores") or {}
    params = run.get("params") or {}
    d = run.get("diff") or {}
    key = lambda r: f"{r['site']}|{r['username']}"
    found = sorted((r for r in results if r["status"] == "bulundu"),
                   key=lambda r: -(scores.get(key(r), {}).get("score", 0)))
    errors = [r for r in results if r["status"] == "hata"]
    created = time.strftime("%d.%m.%Y %H:%M", time.localtime(run.get("created") or time.time()))
    usernames = params.get("usernames") or sorted({r["username"] for r in results})
    new = set(d.get("new") or [])

    rows = []
    for r in found:
        p = r.get("profile") or {}
        sc = scores.get(key(r), {"score": 0, "reasons": []})
        avatar = (f'<img src="{_e(p["avatar"])}" referrerpolicy="no-referrer" alt="" loading="lazy">'
                  if p.get("avatar") else f'<div class="ph">{_e(r["site"][0])}</div>')
        facts = [f"<b>{_e(k)}:</b> {_e(v)}" for k, v in (
            ("Konum", p.get("location")), ("Takipçi", p.get("followers")), ("Katılım", p.get("created")),
            *((p.get("extra") or {}).items())) if v not in (None, "")]
        links = "".join(f'<li><a href="{_e(u)}">{_e(u)}</a></li>' for u in (p.get("links") or [])[:10])
        rows.append(f"""
        <article class="prof">
          <div class="av">{avatar}</div>
          <div class="body">
            <div class="top">
              <h3>{_e(r["site"])} {'<span class="new">YENİ</span>' if key(r) in new else ''}</h3>
              <span class="score {_score_class(sc['score'])}">%{sc['score']}</span>
            </div>
            <a class="url" href="{_e(r['url'])}">{_e(r['url'])}</a>
            {f'<div class="pname">{_e(p.get("name"))}</div>' if p.get("name") else ''}
            {f'<p class="bio">{_e(p.get("bio"))}</p>' if p.get("bio") else ''}
            {f'<div class="facts">{" · ".join(facts)}</div>' if facts else ''}
            {f'<ul class="links">{links}</ul>' if links else ''}
            <details><summary>Puan gerekçesi</summary><ul>{"".join(f"<li>{_e(x)}</li>" for x in sc["reasons"])}</ul></details>
          </div>
        </article>""")

    def section(title: str, items: list[str], empty: str = "") -> str:
        if not items and not empty:
            return ""
        body = "<ul>" + "".join(items) + "</ul>" if items else f'<p class="muted">{empty}</p>'
        return f"<section><h2>{title}</h2>{body}</section>"

    disc = [f'<li><a href="{_e(x["url"])}">{_e(x["site"])}: {_e(x["username"])}</a> '
            f'<span class="muted">← {_e(", ".join(v.split("|")[0] for v in x["via"]))}</span></li>'
            for x in a.get("discovered") or []]
    webs = [f'<li><a href="{_e(x["url"])}">{_e(x["url"])}</a> <span class="muted">← '
            f'{_e(", ".join(v.split("|")[0] for v in x["via"]))}</span></li>' for x in a.get("websites") or []]
    mails = [f'<li>{_e(x["email"])} <span class="muted">← {_e(", ".join(v.split("|")[0] for v in x["via"]))}</span></li>'
             for x in a.get("emails") or []]
    groups = [f'<li>{_e(" = ".join(k.replace("|", " @") for k in g))}</li>' for g in a.get("avatar_groups") or []]
    gone = [f"<li>{_e(k.replace('|', ' @'))}</li>" for k in d.get("gone") or []]
    errs = ", ".join(sorted({r["site"] for r in errors}))

    return f"""<!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sherlock raporu – {_e(run.get("title"))}</title>
<style>
  :root {{ --ink:#1d1f24; --muted:#6b7180; --line:#e3e0d8; --accent:#b77a14; --bg:#fbfaf7;
          --hi:#1f9a5c; --mid:#b88a12; --lo:#a3a8b3; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--ink); font:14px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }}
  main {{ max-width:900px; margin:0 auto; padding:32px 20px 60px; }}
  header {{ border-bottom:2px solid var(--ink); padding-bottom:14px; margin-bottom:22px; display:flex; justify-content:space-between; gap:16px; flex-wrap:wrap; align-items:end; }}
  h1 {{ margin:0; font-size:26px; }} h1 small {{ color:var(--accent); font-size:14px; display:block; letter-spacing:.08em; text-transform:uppercase; }}
  .meta {{ color:var(--muted); font-size:13px; text-align:right; }}
  .stats {{ display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:26px; }}
  .stat {{ border:1px solid var(--line); background:#fff; border-radius:10px; padding:10px 12px; }}
  .stat b {{ font-size:22px; display:block; }} .stat span {{ color:var(--muted); font-size:12px; }}
  h2 {{ font-size:16px; margin:28px 0 10px; border-bottom:1px solid var(--line); padding-bottom:6px; }}
  .prof {{ display:flex; gap:14px; border:1px solid var(--line); background:#fff; border-radius:12px; padding:14px; margin-bottom:10px; break-inside:avoid; }}
  .av img, .ph {{ width:56px; height:56px; border-radius:12px; object-fit:cover; background:#eee; display:grid; place-items:center; font-weight:700; color:var(--muted); }}
  .body {{ flex:1; min-width:0; }}
  .top {{ display:flex; justify-content:space-between; align-items:center; gap:10px; }}
  h3 {{ margin:0; font-size:15px; }}
  .url {{ color:var(--muted); font-size:12px; word-break:break-all; }}
  .pname {{ font-weight:600; margin-top:6px; }}
  .bio {{ margin:4px 0; white-space:pre-line; }}
  .facts {{ font-size:12px; color:var(--muted); }}
  .links {{ margin:6px 0 0; padding-left:18px; font-size:12px; word-break:break-all; }}
  .score {{ font-weight:700; font-size:13px; padding:2px 10px; border-radius:99px; color:#fff; }}
  .score.hi {{ background:var(--hi); }} .score.mid {{ background:var(--mid); }} .score.lo {{ background:var(--lo); }}
  .new {{ background:var(--accent); color:#fff; font-size:10px; padding:1px 6px; border-radius:4px; vertical-align:middle; }}
  details {{ font-size:12px; color:var(--muted); margin-top:6px; }}
  .muted {{ color:var(--muted); }}
  a {{ color:inherit; }}
  ul {{ padding-left:20px; }}
  footer {{ margin-top:40px; font-size:12px; color:var(--muted); border-top:1px solid var(--line); padding-top:12px; }}
  .print {{ position:fixed; right:20px; bottom:20px; background:var(--ink); color:#fff; border:0; border-radius:10px; padding:10px 16px; cursor:pointer; font:inherit; }}
  @media (max-width:600px) {{ .stats {{ grid-template-columns:repeat(2,1fr); }} .meta {{ text-align:left; }} }}
  @media print {{ .print {{ display:none; }} body {{ background:#fff; }} details {{ display:block; }} details > ul {{ display:block; }} a {{ text-decoration:none; }} }}
</style></head>
<body><main>
<header>
  <div><h1><small>Sherlock OSINT raporu</small>{_e(run.get("title"))}</h1></div>
  <div class="meta">{created}<br>{len(usernames)} kullanıcı adı · {len({r["site"] for r in results})} site</div>
</header>
<div class="stats">
  <div class="stat"><b>{len(found)}</b><span>Bulunan profil</span></div>
  <div class="stat"><b>{sum(1 for r in found if scores.get(key(r), {}).get("score", 0) >= 70)}</b><span>Yüksek güvenli</span></div>
  <div class="stat"><b>{len(a.get("discovered") or [])}</b><span>Bağlantılı hesap</span></div>
  <div class="stat"><b>{len(errors)}</b><span>Kontrol edilemedi</span></div>
</div>
{f'<section><h2>Notlar</h2><p style="white-space:pre-line">{_e(run.get("note"))}</p></section>' if run.get("note") else ''}
<section><h2>Bulunan profiller</h2>{"".join(rows) or '<p class="muted">Profil bulunamadı.</p>'}</section>
{section("Profillerden bulunan bağlantılı hesaplar", disc)}
{section("Kişisel web siteleri", webs)}
{section("Profillerde geçen e-postalar", mails)}
{section("Aynı profil fotoğrafını kullanan hesaplar", groups)}
{section("Önceki taramadan bu yana kaybolan profiller", gone)}
<section><h2>Aranan kullanıcı adları</h2><p>{_e(", ".join(usernames))}</p>
{f'<p class="muted">Kontrol edilemeyen siteler: {_e(errs)}</p>' if errs else ''}</section>
<footer>Sherlock v{__version__} ile oluşturuldu. Rapor yalnızca herkese açık bilgilere dayanır; güven puanı
otomatik bir tahmindir ve kesin kimlik tespiti değildir. Sonuçları elle doğrulayın.</footer>
</main>
<button class="print" onclick="print()">Yazdır / PDF</button>
</body></html>"""
