"""Sherlock - kullanıcı adı OSINT aracı."""

__version__ = "0.4.0"
