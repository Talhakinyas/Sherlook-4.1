// The globe owns the data sources. This panel only asks its existing query tools.
const shell = document.createElement('div');
shell.id = 'sherlook-region';
shell.innerHTML = `<button class="region-trigger" type="button">◉ Bu bölgede ne oluyor?</button>
  <section class="region-panel" hidden aria-live="polite">
    <header><strong>Bölge özeti</strong><button class="region-close" type="button" aria-label="Kapat">×</button></header>
    <label>Yarıçap <select class="region-radius"><option value="50">50 km</option><option value="100" selected>100 km</option><option value="250">250 km</option></select></label>
    <div class="region-result">Haritada incelemek istediğiniz bölgeyi merkeze alın.</div>
  </section>`;
document.body.append(shell);
const css = document.createElement('style');
css.textContent = `
  #sherlook-region{position:fixed;left:18px;bottom:18px;z-index:9050;font:13px/1.45 system-ui,sans-serif;color:#eaf4fa}
  #sherlook-region button,#sherlook-region select{font:inherit}
  #sherlook-region .region-trigger{background:#123a4c;border:1px solid #5cbecf;color:#eafcff;border-radius:10px;padding:9px 13px;box-shadow:0 8px 28px #0007;cursor:pointer;font-weight:700}
  #sherlook-region .region-panel{position:absolute;left:0;bottom:48px;width:min(375px,calc(100vw - 36px));max-height:min(68vh,590px);overflow:auto;padding:15px;background:#0b1723f5;border:1px solid #3e7890;border-radius:12px;box-shadow:0 18px 50px #0009;backdrop-filter:blur(16px)}
  #sherlook-region .region-panel[hidden]{display:none}#sherlook-region header{display:flex;justify-content:space-between;align-items:center;font-size:17px;margin-bottom:10px}#sherlook-region .region-close{border:0;background:none;color:#fff;font-size:22px;cursor:pointer}#sherlook-region label{color:#9bb5c2}#sherlook-region select{background:#142c3c;color:#fff;border:1px solid #496f81;border-radius:6px;padding:3px 6px;margin-left:6px}#sherlook-region .region-result{margin-top:12px}#sherlook-region .region-section{border-top:1px solid #294657;padding:10px 0}#sherlook-region .region-section strong{color:#84d8e5}#sherlook-region .region-section p{margin:5px 0 0}#sherlook-region .region-section small,#sherlook-region .region-meta{color:#9bb5c2}#sherlook-region .region-error{color:#ffbc9a}`;
document.head.append(css);

const panel = shell.querySelector('.region-panel');
const output = shell.querySelector('.region-result');
const radiusSelect = shell.querySelector('.region-radius');
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const names = { weather: 'Hava durumu', earthquakes: 'Depremler', fires: 'Yangınlar', aircraft: 'Uçaklar', vessels: 'Gemiler', cyclones: 'Kasırgalar', satellites: 'Şu an üstteki uydular (istasyon grubu)' };
const sources = { weather: 'Hava durumu servisi', earthquakes: 'USGS', fires: 'NASA FIRMS', aircraft: 'OpenSky / ADS-B', vessels: 'AISStream', cyclones: 'NOAA', satellites: 'CelesTrak' };
let pending = 0;
let catalogPromise;

function globeCenter() {
  try {
    const viewer = window.__godsEyeView?.viewer;
    const scene = viewer?.scene;
    const canvas = scene?.canvas;
    if (!scene?.globe || !canvas) return null;
    const ray = viewer.camera.getPickRay({ x: canvas.clientWidth / 2, y: canvas.clientHeight / 2 });
    const cartesian = (ray && scene.globe.pick(ray, scene)) ||
      viewer.camera.pickEllipsoid({ x: canvas.clientWidth / 2, y: canvas.clientHeight / 2 }, scene.globe.ellipsoid);
    const point = cartesian && scene.globe.ellipsoid.cartesianToCartographic(cartesian);
    if (!point) return null;
    return { lat: point.latitude * 180 / Math.PI, lon: point.longitude * 180 / Math.PI };
  } catch { return null; }
}

function queryCatalog() {
  catalogPromise ??= Promise.all([import('./tools/index.js'), import('./tools/services.js')])
    .then(([{ composeCatalog, coreTools }, { createToolServices }]) => composeCatalog({
      tools: coreTools,
      services: createToolServices({
        fetchImpl: (...args) => globalThis.fetch(...args),
        appUrl: location.origin,
      }),
    }));
  return catalogPromise;
}

function section(key, answer) {
  const title = names[key];
  const source = sources[key];
  if (!answer || answer.unavailable)
    return `<div class="region-section"><strong>${title}</strong><p class="region-error">Veri alınamadı</p><small>Kaynak: ${source}</small></div>`;
  const data = answer.data || {};
  const count = Number.isFinite(data.total) ? `${data.total} kayıt` : '';
  const stale = data.stale || data.freshness === 'stale' || data.missing_sources?.length ? ' · Gecikmeli / kısmi veri' : '';
  const weather = data.weather;
  const weatherText = weather ? [
    Number.isFinite(weather.temperature_c) ? `${Math.round(weather.temperature_c)} °C` : null,
    Number.isFinite(weather.wind_kph) ? `Rüzgâr ${Math.round(weather.wind_kph)} km/sa` : null,
    Number.isFinite(weather.cloud_cover_pct) ? `Bulut %${Math.round(weather.cloud_cover_pct)}` : null,
  ].filter(Boolean).join(' · ') : 'Güncel ölçüm yok';
  const text = key === 'weather' ? weatherText : count || answer.summary;
  const rows = Array.isArray(data.rows) ? data.rows.slice(0, 3).map(row =>
    row.name || row.callsign || row.place || row.label || (Number.isFinite(row.magnitude) ? `M${row.magnitude}` : '')
  ).filter(Boolean).join(' · ') : '';
  return `<div class="region-section"><strong>${title}</strong><p>${escapeHtml(text)}</p>${rows ? `<small>${escapeHtml(rows)}</small><br>` : ''}<small>Kaynak: ${source}${stale}</small></div>`;
}

async function refresh() {
  const point = globeCenter();
  if (!point) {
    output.innerHTML = '<p class="region-error">Haritanın merkezinde bir yer görünmüyor. Dünya üzerindeki bir bölgeye yakınlaşın.</p>';
    return;
  }
  const radius = Number(radiusSelect.value);
  const request = ++pending;
  output.textContent = 'Bölge verileri toplanıyor…';
  try {
    const catalog = await queryCatalog();
    const [brief, satellites] = await Promise.allSettled([
      catalog.call('situation_brief', { area: { lat: point.lat, lon: point.lon, radius_km: radius } }),
      catalog.call('satellites_overhead', { location: point, limit: 5 }),
    ]);
    if (request !== pending) return;
    const sections = brief.status === 'fulfilled' ? brief.value.data?.sections || {} : {};
    output.innerHTML = `<p class="region-meta">${point.lat.toFixed(3)}°, ${point.lon.toFixed(3)}° · ${radius} km · ${new Date().toLocaleString('tr-TR')}</p>` +
      Object.keys(names).map(key => section(key, key === 'satellites'
        ? satellites.status === 'fulfilled' ? satellites.value : { unavailable: true }
        : sections[key])).join('');
  } catch {
    if (request === pending) output.innerHTML = '<p class="region-error">Özet şu anda hazırlanamadı. Biraz sonra tekrar deneyin.</p>';
  }
}

shell.querySelector('.region-trigger').addEventListener('click', () => { panel.hidden = false; refresh(); });
shell.querySelector('.region-close').addEventListener('click', () => { panel.hidden = true; ++pending; });
radiusSelect.addEventListener('change', refresh);
