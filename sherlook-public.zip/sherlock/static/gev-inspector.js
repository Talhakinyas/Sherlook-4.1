// Sherlook detail panel for every layer publishing a selected context record.
(() => {
  const movingLayers = new Set(['flights', 'satellites', 'ais-live-vessels']);
  const labels = {
    flights: 'Uçak', military: 'Askerî uçak', satellites: 'Uydu', 'ais-live-vessels': 'Gemi',
    'weather-cyclones': 'Kasırga', 'wildlife-sightings': 'Yaban hayatı',
  };
  const icon = { flights: '✈', satellites: '◉', 'ais-live-vessels': '◆' };
  const host = document.createElement('aside');
  host.id = 'sherlook-inspector';
  host.setAttribute('aria-live', 'polite');
  host.hidden = true;
  document.body.append(host);
  const style = document.createElement('style');
  style.textContent = `
    #sherlook-inspector{position:fixed;right:18px;bottom:18px;z-index:9000;width:min(355px,calc(100vw - 36px));max-height:min(68vh,620px);overflow:auto;background:#0b1723ee;color:#eaf4fa;border:1px solid #3e7890;border-radius:14px;box-shadow:0 18px 50px #0009;padding:18px;font:14px/1.45 system-ui,sans-serif;backdrop-filter:blur(16px)}
    #sherlook-inspector[hidden]{display:none}#sherlook-inspector h2{font-size:19px;margin:3px 32px 12px 0;color:#fff;overflow-wrap:anywhere}#sherlook-inspector h3{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#79cfdf;margin:16px 0 7px}#sherlook-inspector p{margin:5px 0}#sherlook-inspector dl{display:grid;grid-template-columns:110px 1fr;gap:5px 9px;margin:0}#sherlook-inspector dt{color:#96b3c4}#sherlook-inspector dd{margin:0;overflow-wrap:anywhere}#sherlook-inspector a{color:#80dcea}#sherlook-inspector button{position:absolute;right:12px;top:10px;border:0;background:transparent;color:#fff;font-size:22px;cursor:pointer}#sherlook-inspector .visual{height:72px;max-width:160px;border-radius:9px;background:linear-gradient(130deg,#18354a,#0c1c2b);display:grid;place-items:center;font-size:38px;color:#70c9d9;overflow:hidden}#sherlook-inspector .visual img{display:block;width:100%;height:100%;object-fit:cover}#sherlook-inspector small{color:#9bb5c2}#sherlook-inspector .tag{color:#8ee0c4}`;
  document.head.append(style);

  let serial = 0;
  const safe = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const row = (label, value) => value !== null && value !== undefined && value !== '' ? `<dt>${safe(label)}</dt><dd>${safe(value)}</dd>` : '';
  function current() {
    const store = window.__gevContextStore;
    const record = store?.entities?.get(store.selectedEntityId);
    return record?.layerId && record?.label ? record : null;
  }
  const fieldLabels = {
    frp: 'Yangın gücü', confidence: 'Güven', age: 'Yaş', sensor: 'Sensör',
    classification: 'Sınıf', classificationName: 'Sınıf adı', basin: 'Havza',
    advisoryNumber: 'Bülten', operator: 'Operatör', manufacturer: 'Üretici',
    cameraType: 'Kamera türü', zone: 'Bölge', directionDeg: 'Yön', ref: 'Referans',
    lastVerified: 'Son doğrulama', osmId: 'OSM kimliği', class: 'Sınıf',
    memberNames: 'Adlar', primaryType: 'Tür', placeTypes: 'Yer türleri',
    validation: 'Doğrulama', retrievedAt: 'Alınma zamanı', quality: 'Kalite',
    iconic: 'Tür', obscured: 'Konum gizli', speed: 'Hız', altitude: 'İrtifa',
  };
  function showGeneric(record) {
    const properties = record.properties || {};
    const entries = Object.entries(properties)
      .filter(([key, value]) => !['name', 'route', 'destination'].includes(key) && value !== null && value !== undefined && value !== '')
      .slice(0, 14);
    const details = entries.map(([key, value]) => {
      const display = Array.isArray(value) ? value.join(', ') : typeof value === 'object' ? JSON.stringify(value) : String(value);
      return row(fieldLabels[key] || key.replace(/([A-Z])/g, ' $1'), display.slice(0, 240));
    }).join('');
    const coords = Number.isFinite(record.latitude) && Number.isFinite(record.longitude)
      ? row('Konum', `${record.latitude.toFixed(3)}°, ${record.longitude.toFixed(3)}°`) : '';
    const route = properties.route || properties.destination;
    host.innerHTML = `<button type="button" aria-label="Bilgi kartını kapat">×</button><small class="tag">${safe(labels[record.layerId] || record.layerName || record.layerId)}</small><h2>${safe(record.label)}</h2><div class="visual" aria-hidden="true">◎</div><h3>Bilgiler</h3><dl>${details || '<dt>Durum</dt><dd>Ek ayrıntı sağlanmadı</dd>'}${coords}${row('Kaynak', record.source)}</dl>${route ? `<h3>Rota / hedef</h3><p>${safe(route)}</p>` : ''}<h3>Görsel</h3><small>Bu katmanda doğrulanmış görsel sağlanmıyor.</small>`;
    host.querySelector('button').addEventListener('click', () => { host.hidden = true; });
    host.hidden = false;
  }
  function show() {
    const record = current();
    if (!record) { host.hidden = true; return; }
    ++serial;
    if (!movingLayers.has(record.layerId)) { showGeneric(record); return; }
    const p = record.properties || {};
    const kind = record.layerId;
    const id = kind === 'flights' ? p.registration || p.icao24 : kind === 'satellites' ? p.noradId : p.mmsi;
    const route = kind === 'flights' ? p.route : kind === 'ais-live-vessels' ? p.destination : null;
    const routeNote = kind === 'flights' ? 'Doğrulanmış kalkış ve varış' : kind === 'satellites' ? 'Tahmini yörünge haritada çiziliyor' : 'Son konumların izi haritada çiziliyor';
    const routeValue = route ? safe(route) : kind === 'satellites' ? 'Yörünge görünümü' : kind === 'ais-live-vessels' ? 'Bildirilmiş varış yok' : 'Doğrulanmış rota yok';
    host.innerHTML = `<button type="button" aria-label="Bilgi kartını kapat">×</button><small class="tag">${labels[kind]} · ${safe(p.status || 'son alınan veri')}</small><h2>${safe(record.label || p.name || id || labels[kind])}</h2><div class="visual" aria-label="Görsel alanı">${icon[kind]}</div><h3>Bilgiler</h3><dl>${row(kind === 'flights' ? 'ICAO' : kind === 'satellites' ? 'NORAD' : 'MMSI', kind === 'flights' ? p.icao24 : id)}${row('Kayıt', p.registration)}${row('Operatör', p.operator)}${row('Tür / sınıf', p.type || p.class)}${row('İrtifa', p.altitude)}${row('Hız', p.speed || (p.speedKt != null ? p.speedKt + ' kn' : ''))}${row('Yön', p.heading || p.course)}${row('Son konum', Number.isFinite(record.latitude) && Number.isFinite(record.longitude) ? `${record.latitude.toFixed(3)}°, ${record.longitude.toFixed(3)}°` : '')}</dl><h3>Rota</h3><p>${routeValue}</p><small>${routeNote}${kind === 'ais-live-vessels' ? ' · Varış AIS beyanıdır.' : ''}</small><h3>Fotoğraf</h3><small>Doğrulanmış fotoğraf aranıyor…</small>`;
    host.querySelector('button').addEventListener('click', () => { host.hidden = true; });
    host.hidden = false;
    const requestId = serial;
    if (kind === 'satellites') {
      host.querySelector('h3:last-of-type + small').textContent = 'Uydu fotoğrafı doğrulanamadı; simge gösteriliyor.';
    } else {
      loadPhoto(record, requestId);
    }
  }
  async function findCommonsPhoto(query, matchesTitle) {
    if (!query) return null;
    const url = new URL('https://commons.wikimedia.org/w/api.php');
    url.search = new URLSearchParams({action:'query',generator:'search',gsrsearch:`file:${query}`,gsrnamespace:'6',gsrlimit:'20',prop:'imageinfo',iiprop:'url|extmetadata',iiurlwidth:'360',format:'json',origin:'*'});
    const response = await fetch(url, {signal:AbortSignal.timeout(5000)});
    if (!response.ok) return null;
    const pages = Object.values((await response.json()).query?.pages || {});
    return pages.find(page => matchesTitle(page.title || '') && page.imageinfo?.[0]?.thumburl) || null;
  }
  async function loadPhoto(record, requestId) {
    const p = record.properties || {};
    const exactIdentifier = String(record.layerId === 'flights' ? p.registration || p.icao24 : p.mmsi || '').trim();
    try {
      let match = null;
      let representative = false;
      if (record.layerId === 'flights' && p.operator && p.type) {
        const company = String(p.operator).trim().toLowerCase();
        const model = String(p.type).trim().toLowerCase();
        try {
          match = await findCommonsPhoto(`${company} ${model}`, title => {
            const normalized = title.toLowerCase();
            return normalized.includes(company) && normalized.includes(model);
          });
        } catch { /* Registration lookup remains available. */ }
        representative = Boolean(match);
      }
      if (!match && exactIdentifier.length >= 4) {
        const escaped = exactIdentifier.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const identifierPattern = new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, 'i');
        match = await findCommonsPhoto(exactIdentifier, title => identifierPattern.test(title));
      }
      if (requestId !== serial) return;
      if (!match) { noPhoto(requestId); return; }
      const info = match.imageinfo[0];
      const visual = host.querySelector('.visual');
      visual.replaceChildren();
      const img = document.createElement('img'); img.src = info.thumburl; img.alt = `${record.label} görseli`; img.referrerPolicy = 'no-referrer';
      img.onerror = () => { visual.textContent = icon[record.layerId]; noPhoto(requestId); };
      visual.append(img);
      const note = host.querySelector('h3:last-of-type + small');
      note.innerHTML = `${representative ? 'Firma ve modele ait temsili fotoğraf · ' : 'Kayıt kimliğiyle eşleşen fotoğraf · '}<a href="${safe(info.descriptionurl)}" target="_blank" rel="noopener noreferrer">Wikimedia Commons: kaynak ve lisans</a>`;
    } catch { noPhoto(requestId); }
  }
  function noPhoto(requestId) {
    if (requestId !== serial || host.hidden) return;
    const note = host.querySelector('h3:last-of-type + small');
    if (note) note.textContent = 'Bu kimlik için doğrulanmış fotoğraf bulunamadı.';
  }
  const schedule = () => requestAnimationFrame(show);
  window.addEventListener('gev:awareness-subject-selected', schedule);
  window.addEventListener('gev:entity-selected', schedule);
  window.addEventListener('gev:entity-selection-cleared', schedule);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') host.hidden = true;
  });
})();
