"""Aramaları yerel bir SQLite veritabanında "vaka" olarak saklar.

Konum: SHERLOCK_DATA ortam değişkeni, yoksa kullanıcı klasöründe ~/.sherlock/sherlock.db
Her vaka (aynı kişi / aynı kullanıcı adları) birden çok tarama içerebilir; yeni tarama
öncekiyle karşılaştırılarak yeni bulunan ve kaybolan profiller çıkarılır.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path

from .analysis import diff
from .variants import normalize

_lock = threading.Lock()


def data_dir() -> Path:
    base = Path(os.environ.get("SHERLOCK_DATA") or Path.home() / ".sherlock")
    base.mkdir(parents=True, exist_ok=True)
    return base


def db_path() -> Path:
    return data_dir() / "sherlock.db"


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(db_path())
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.executescript("""
        CREATE TABLE IF NOT EXISTS cases (
            id INTEGER PRIMARY KEY, key TEXT UNIQUE NOT NULL, title TEXT NOT NULL,
            kind TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL, note TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY, case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
            created REAL NOT NULL, params TEXT NOT NULL, results TEXT NOT NULL,
            analysis TEXT NOT NULL, diff TEXT
        );
    """)
    return c


@contextmanager
def _db():
    """Bağlantıyı açar, işlem bitince kaydedip kapatır."""
    c = _conn()
    try:
        with c:
            yield c
    finally:
        c.close()


def case_key(params: dict) -> tuple[str, str, str]:
    """(anahtar, başlık, tür) – aynı aramalar aynı vakaya düşer."""
    if params.get("name"):
        return "name:" + normalize(params["name"]), params["name"], "name"
    if params.get("email"):
        return "email:" + params["email"].lower(), params["email"], "email"
    users = sorted(params.get("usernames") or [])
    title = users[0] if len(users) == 1 else f"{users[0]} +{len(users) - 1}"
    return "users:" + ",".join(users), title, "users"


def save_run(params: dict, results: list[dict], analysis: dict) -> dict:
    """Taramayı kaydeder; {'case_id', 'run_id', 'diff'} döndürür (ilk taramada diff None)."""
    key, title, kind = case_key(params)
    now = time.time()
    with _lock, _db() as c:
        row = c.execute("SELECT id FROM cases WHERE key = ?", (key,)).fetchone()
        if row:
            case_id = row["id"]
            c.execute("UPDATE cases SET updated = ? WHERE id = ?", (now, case_id))
        else:
            case_id = c.execute("INSERT INTO cases (key, title, kind, created, updated) VALUES (?,?,?,?,?)",
                                (key, title, kind, now, now)).lastrowid
        prev = c.execute("SELECT results FROM runs WHERE case_id = ? ORDER BY created DESC LIMIT 1",
                         (case_id,)).fetchone()
        d = diff(json.loads(prev["results"]), results) if prev else None
        run_id = c.execute(
            "INSERT INTO runs (case_id, created, params, results, analysis, diff) VALUES (?,?,?,?,?,?)",
            (case_id, now, json.dumps(params, ensure_ascii=False), json.dumps(results, ensure_ascii=False),
             json.dumps(analysis, ensure_ascii=False), json.dumps(d) if d else None)).lastrowid
    return {"case_id": case_id, "run_id": run_id, "diff": d}


def list_cases() -> list[dict]:
    with _db() as c:
        rows = c.execute("""
            SELECT c.id, c.title, c.kind, c.created, c.updated, c.note,
                   COUNT(r.id) AS runs, MAX(r.id) AS last_run
            FROM cases c LEFT JOIN runs r ON r.case_id = c.id
            GROUP BY c.id ORDER BY c.updated DESC
        """).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            last = c.execute("SELECT results FROM runs WHERE id = ?", (r["last_run"],)).fetchone()
            d["found"] = sum(x["status"] == "bulundu" for x in json.loads(last["results"])) if last else 0
            out.append(d)
        return out


def get_run(run_id: int) -> dict | None:
    with _db() as c:
        r = c.execute("""SELECT r.*, c.title, c.kind, c.note FROM runs r JOIN cases c ON c.id = r.case_id
                         WHERE r.id = ?""", (run_id,)).fetchone()
        if not r:
            return None
        runs = c.execute("SELECT id, created FROM runs WHERE case_id = ? ORDER BY created DESC",
                         (r["case_id"],)).fetchall()
    return {
        "run_id": r["id"], "case_id": r["case_id"], "title": r["title"], "kind": r["kind"],
        "note": r["note"], "created": r["created"],
        "params": json.loads(r["params"]), "results": json.loads(r["results"]),
        "analysis": json.loads(r["analysis"]), "diff": json.loads(r["diff"]) if r["diff"] else None,
        "runs": [dict(x) for x in runs],
    }


def set_note(case_id: int, note: str) -> None:
    with _lock, _db() as c:
        c.execute("UPDATE cases SET note = ? WHERE id = ?", (note[:5000], case_id))


def delete_case(case_id: int) -> None:
    with _lock, _db() as c:
        c.execute("DELETE FROM cases WHERE id = ?", (case_id,))
