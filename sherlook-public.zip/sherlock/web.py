"""Sherlock web arayüzü: `python -m sherlock.web` ile başlatılır."""

from __future__ import annotations

import argparse
import json
import socket
import webbrowser
from pathlib import Path
from urllib.parse import urlparse

from flask import Flask, Response, abort, jsonify, request, send_from_directory

from . import __version__, storage
from .analysis import analyze
from .core import load_sites, make_session, search_many
from .emailcheck import lookup
from .geocode import geocode
from .gev import manager as gev
from .report import render
from .variants import generate

STATIC_DIR = Path(__file__).with_name("static")
MAX_USERNAMES = 60
LOCAL_HOSTS = {"127.0.0.1", "localhost", "[::1]"}

app = Flask(__name__, static_folder=None)
app.config["BIND_HOST"] = "127.0.0.1"
SITES = load_sites()


@app.before_request
def same_origin_only():
    """Başka web sitelerinin tarayıcınız üzerinden bu yerel API'yi kullanmasını engeller."""
    origin = request.headers.get("Origin")
    if origin and urlparse(origin).netloc != request.host:
        abort(403)
    # DNS rebinding'e karşı: yalnızca yerelde çalışırken Host başlığı yerel olmalı.
    if app.config["BIND_HOST"] in LOCAL_HOSTS and request.host.rsplit(":", 1)[0] not in LOCAL_HOSTS:
        abort(403)


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=e.description), 400


@app.get("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.get("/api/sites")
def sites():
    return {"version": __version__,
            "sites": [{"name": k, "cat": SITES[k].get("cat", "Diğer")} for k in sorted(SITES, key=str.lower)]}


@app.get("/api/variants")
def api_variants():
    name = request.args.get("name", "").strip()
    if not name or len(name) > 100:
        abort(400, "Bir ad soyad veya kullanıcı adı girin.")
    extras = [x for x in request.args.get("extra", "").replace(",", " ").split() if x]
    variants = generate(
        name,
        nickname=request.args.get("nick") or None,
        year=request.args.get("year") or None,
        extras=extras[:5],
        limit=min(max(request.args.get("limit", 40, type=int), 1), MAX_USERNAMES),
    )
    return {"variants": variants}


@app.get("/api/search")
def api_search():
    usernames = list(dict.fromkeys(
        u.strip().lstrip("@") for u in request.args.getlist("username") if u.strip()))
    if not usernames or len(usernames) > MAX_USERNAMES or any(len(u) > 100 for u in usernames):
        abort(400, f"1 ile {MAX_USERNAMES} arasında geçerli kullanıcı adı girin.")
    selected = request.args.getlist("site")
    targets = {k: v for k, v in SITES.items() if k in selected} if selected else SITES
    if not targets:
        abort(400, "Geçerli bir site seçin.")
    timeout = min(max(request.args.get("timeout", 10, type=float), 1), 60)
    proxy = request.args.get("proxy", "").strip() or None
    enrich = request.args.get("enrich", "1") != "0"
    context = {"name": request.args.get("name") or None, "email": request.args.get("email") or None,
               "usernames": usernames}
    try:
        make_session(1, proxy)
    except ValueError as exc:
        abort(400, str(exc))

    def stream():
        yield _sse("start", {"usernames": usernames, "total": len(targets) * len(usernames)})
        rows = []
        for r in search_many(usernames, targets, timeout=timeout, proxy=proxy, enrich=enrich):
            d = r.to_dict()
            rows.append(d)
            yield _sse("result", d)
        order = {u: i for i, u in enumerate(usernames)}
        rows.sort(key=lambda r: (order[r["username"]], r["site"].lower()))
        analysis = analyze(rows, SITES, context)
        params = {"usernames": usernames, "name": context["name"], "email": context["email"],
                  "sites": selected or None}
        try:
            saved = storage.save_run(params, rows, analysis)
        except Exception as exc:  # kayıt hatası aramayı bozmasın
            saved = {"case_id": None, "run_id": None, "diff": None, "error": str(exc)}
        yield _sse("analysis", {"analysis": analysis, **saved})
        yield _sse("done", {})

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/api/email")
def api_email():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip()
    if not email or len(email) > 254:
        abort(400, "Bir e-posta adresi girin.")
    proxy = str(data.get("proxy") or "").strip() or None
    try:
        session = make_session(4, proxy)
    except ValueError as exc:
        abort(400, str(exc))
    return lookup(session, email, str(data.get("hibp_key") or "").strip() or None)


@app.get("/api/cases")
def api_cases():
    return {"cases": storage.list_cases(), "db": str(storage.db_path())}


@app.delete("/api/cases/<int:case_id>")
def api_case_delete(case_id: int):
    storage.delete_case(case_id)
    return {"ok": True}


@app.post("/api/cases/<int:case_id>/note")
def api_case_note(case_id: int):
    storage.set_note(case_id, str((request.get_json(silent=True) or {}).get("note", "")))
    return {"ok": True}


@app.get("/api/runs/<int:run_id>")
def api_run(run_id: int):
    run = storage.get_run(run_id)
    if not run:
        abort(404)
    return run


@app.get("/report/<int:run_id>")
def report(run_id: int):
    run = storage.get_run(run_id)
    if not run:
        abort(404)
    return Response(render(run), mimetype="text/html")


@app.get("/api/geocode")
def api_geocode():
    q = request.args.get("q", "").strip()
    if not q or len(q) > 200:
        abort(400, "Bir konum girin.")
    try:
        return {"query": q, "result": geocode(q)}
    except Exception as exc:  # ağ hatası vb.
        return {"query": q, "result": None, "error": f"Konum aranamadı ({type(exc).__name__})"}


@app.get("/api/gev")
def api_gev_status():
    return gev.status()


@app.post("/api/gev/<action>")
def api_gev_action(action: str):
    actions = {"install": gev.install, "start": gev.start, "stop": gev.stop}
    if action not in actions:
        abort(404)
    try:
        actions[action]()
    except RuntimeError as exc:
        abort(400, str(exc))
    return gev.status()


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def _free_port(host: str, start: int) -> int:
    for port in range(start, start + 20):
        with socket.socket() as s:
            try:
                s.bind((host, port))
                return port
            except OSError:
                continue
    return start


def main() -> None:
    p = argparse.ArgumentParser(prog="sherlock-web", description="Sherlook web arayüzü")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5000)
    p.add_argument("--no-browser", action="store_true", help="Tarayıcıyı otomatik açma")
    args = p.parse_args()
    app.config["BIND_HOST"] = args.host
    port = _free_port(args.host, args.port)
    gev.frame_ancestors = f"http://127.0.0.1:{port} http://localhost:{port}"
    url = f"http://{'127.0.0.1' if args.host in ('0.0.0.0', '::') else args.host}:{port}"
    print(f"[*] Sherlook arayüzü: {url}")
    print("[*] Kapatmak için bu pencereyi kapatın veya Ctrl+C'ye basın.")
    if not args.no_browser:
        webbrowser.open(url)
    app.run(host=args.host, port=port, threaded=True)


if __name__ == "__main__":
    main()
