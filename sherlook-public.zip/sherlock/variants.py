"""Ad soyad veya kullanıcı adından olası kullanıcı adı kombinasyonları üretir."""

from __future__ import annotations

import re
from typing import Iterable

TR_MAP = str.maketrans({
    "ç": "c", "ğ": "g", "ı": "i", "ö": "o", "ş": "s", "ü": "u",
    "â": "a", "î": "i", "û": "u", "é": "e", "è": "e", "ä": "a", "ë": "e",
})
SEPARATORS = ("", ".", "_", "-")
MIN_LEN, MAX_LEN = 3, 30


def normalize(text: str) -> str:
    """'İsmail Şahin' -> 'ismail sahin' (Türkçe büyük/küçük harf kurallarıyla)."""
    text = text.replace("I", "ı").replace("İ", "i").lower().translate(TR_MAP)
    return re.sub(r"[^a-z0-9 ]+", " ", text).strip()


def _numbers(year: str | int | None, extras: Iterable[str]) -> list[str]:
    nums: list[str] = []
    if year:
        y = re.sub(r"\D", "", str(year))
        if len(y) == 4:
            nums += [y, y[2:]]
        elif y:
            nums.append(y)
    nums += [re.sub(r"\D", "", e) for e in extras]
    return [n for n in dict.fromkeys(nums) if n]


def generate(
    name: str,
    nickname: str | None = None,
    year: str | int | None = None,
    extras: Iterable[str] = (),
    separators: Iterable[str] = SEPARATORS,
    limit: int = 40,
) -> list[str]:
    """Olasılığı yüksekten düşüğe sıralı, tekrarsız kullanıcı adı listesi döndürür.

    `name` tek kelimeyse (ör. mevcut bir kullanıcı adı) ön/son ek varyasyonları,
    birden çok kelimeyse ad-soyad kombinasyonları üretilir.
    """
    seps = list(dict.fromkeys(separators)) or [""]
    nums = _numbers(year, extras)
    words = normalize(name).split()
    nick = normalize(nickname or "").replace(" ", "")
    # Üç öncelik katmanı: en olası biçimler, sayılı biçimler, zayıf olasılıklar.
    strong: list[str] = []
    weak: list[str] = []
    bases: list[str] = []  # sayı eklenecek ana biçimler

    if nick:
        strong.append(nick)
        bases.append(nick)

    if len(words) >= 2:
        first, last = words[0], words[-1]
        firsts = "".join(words[:-1])  # "mehmet ali yılmaz" -> "mehmetali"
        strong += [f"{first}{s}{last}" for s in seps]
        strong += [f"{first[0]}{s}{last}" for s in seps[:2]]
        strong += [f"{last}{s}{first}" for s in seps[:2]]
        if firsts != first:
            strong += [f"{firsts}{s}{last}" for s in seps[:3]]
        bases += [first + last, f"{first}_{last}", f"{first}.{last}", first[0] + last]
        weak += [f"{last}{s}{first}" for s in seps[2:]]
        weak += [f"{first[0]}{s}{last}" for s in seps[2:]]
        weak += [f"{first}{s}{last[0]}" for s in seps]
        weak += [first + last + first[0], last + first[0]]
        if len(words) >= 3:
            weak += ["".join(w[0] for w in words[:-1]) + last, f"{first}{words[1][0]}{last}"]
        if nick:
            weak += [f"{nick}{s}{last}" for s in seps]
        weak += [first, last]
        bases.append(first)
    elif words:
        word = "".join(words)
        strong.append(word)
        bases.append(word)
        for pre in ("the", "real", "its", "im", "iam"):
            weak += [pre + word, f"{pre}_{word}"]
        for suf in ("official", "tr", "x", "1", "01"):
            weak += [word + suf, f"{word}_{suf}"]
        weak += [f"{word}_", f"_{word}", f"{word}{word[-1]}"]

    numbered = [c for b in bases for n in nums for c in (b + n, f"{b}_{n}")]
    out = strong + numbered + weak

    seen: dict[str, None] = {}
    for c in out:
        if MIN_LEN <= len(c) <= MAX_LEN and re.fullmatch(r"[a-z0-9][a-z0-9._-]*", c):
            seen.setdefault(c, None)
    return list(seen)[:limit]
