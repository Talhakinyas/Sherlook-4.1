"""Profillerdeki konum metinlerini ŞEHİR düzeyinde koordinata çevirir.

OpenStreetMap Nominatim kullanılır (kullanım kuralları: saniyede en fazla 1 istek,
uygulamayı tanıtan User-Agent, sonuçları önbelleğe alma). Yalnızca yerleşim yeri,
il/eyalet veya ülke eşleşmeleri kabul edilir; sokak/adres düzeyinde sonuç döndürülmez.
"""

from __future__ import annotations

import json
import re
import threading
import time

import requests

from . import __version__
from .storage import data_dir
from .variants import normalize

NOMINATIM = "https://nominatim.openstreetmap.org/search"
USER_AGENT = f"sherlock-osint/{__version__} (yerel OSINT araci)"
# Kaba konum: aranan ayrıntı düzeyleri ve kamera yüksekliği (metre)
LEVELS = (("settlement", 30_000), ("state", 250_000), ("country", 1_500_000))

# Çevrimdışı şehir listesi: Türkiye'nin 81 ili + büyük dünya şehirleri ve ülkeler.
# Listede olan konumlar internete sorulmadan bulunur. Biçim: ad|enlem|boylam|takma adlar
_CITIES = """
Adana|37.00|35.32
Adıyaman|37.76|38.28
Afyonkarahisar|38.76|30.54|afyon
Ağrı|39.72|43.05
Amasya|40.65|35.83
Ankara|39.93|32.86
Antalya|36.90|30.70
Artvin|41.18|41.82
Aydın|37.85|27.85
Balıkesir|39.65|27.88
Bilecik|40.14|29.98
Bingöl|38.88|40.50
Bitlis|38.40|42.11
Bolu|40.73|31.61
Burdur|37.72|30.29
Bursa|40.19|29.06
Çanakkale|40.15|26.41
Çankırı|40.60|33.62
Çorum|40.55|34.95
Denizli|37.78|29.09
Diyarbakır|37.91|40.24
Edirne|41.68|26.56
Elazığ|38.68|39.22
Erzincan|39.75|39.49
Erzurum|39.90|41.27
Eskişehir|39.78|30.52
Gaziantep|37.07|37.38|antep
Giresun|40.91|38.39
Gümüşhane|40.46|39.48
Hakkari|37.58|43.74
Hatay|36.20|36.16|antakya
Isparta|37.76|30.55
Mersin|36.81|34.64|içel
İstanbul|41.01|28.98|istanbul
İzmir|38.42|27.14|izmir
Kars|40.60|43.10
Kastamonu|41.38|33.78
Kayseri|38.73|35.48
Kırklareli|41.73|27.22
Kırşehir|39.15|34.17
Kocaeli|40.77|29.92|izmit
Konya|37.87|32.48
Kütahya|39.42|29.98
Malatya|38.35|38.31
Manisa|38.61|27.43
Kahramanmaraş|37.58|36.94|maraş
Mardin|37.31|40.74
Muğla|37.22|28.36
Muş|38.75|41.51
Nevşehir|38.62|34.71
Niğde|37.97|34.68
Ordu|40.98|37.88
Rize|41.02|40.52
Sakarya|40.78|30.40|adapazarı
Samsun|41.29|36.33
Siirt|37.93|41.94
Sinop|42.03|35.15
Sivas|39.75|37.02
Tekirdağ|40.98|27.51
Tokat|40.31|36.55
Trabzon|41.00|39.72
Tunceli|39.11|39.55
Şanlıurfa|37.17|38.79|urfa
Uşak|38.68|29.41
Van|38.50|43.38
Yozgat|39.82|34.81
Zonguldak|41.45|31.79
Aksaray|38.37|34.03
Bayburt|40.26|40.23
Karaman|37.18|33.22
Kırıkkale|39.85|33.51
Batman|37.88|41.13
Şırnak|37.52|42.46
Bartın|41.64|32.34
Ardahan|41.11|42.70
Iğdır|39.92|44.05
Yalova|40.65|29.27
Karabük|41.20|32.62
Kilis|36.72|37.12
Osmaniye|37.07|36.25
Düzce|40.84|31.16
London|51.51|-0.13|londra
Paris|48.86|2.35
Berlin|52.52|13.40
Amsterdam|52.37|4.90
Brussels|50.85|4.35|brüksel
Vienna|48.21|16.37|viyana|wien
Munich|48.14|11.58|münih|münchen
Hamburg|53.55|9.99
Frankfurt|50.11|8.68
Cologne|50.94|6.96|köln
Madrid|40.42|-3.70
Barcelona|41.39|2.17
Rome|41.90|12.50|roma
Milan|45.46|9.19|milano
Moscow|55.76|37.62|moskova
Kyiv|50.45|30.52|kiev
Athens|37.98|23.73|atina
Sofia|42.70|23.32|sofya
Baku|40.41|49.87|bakü
Tbilisi|41.72|44.79|tiflis
Dubai|25.20|55.27
Doha|25.29|51.53
Riyadh|24.71|46.68|riyad
Tehran|35.69|51.39|tahran
Cairo|30.04|31.24|kahire
New York|40.71|-74.01|nyc|new york city
San Francisco|37.77|-122.42|sf
Los Angeles|34.05|-118.24|la
Seattle|47.61|-122.33
Chicago|41.88|-87.63
Toronto|43.65|-79.38
Tokyo|35.68|139.69
Seoul|37.57|126.98
Beijing|39.90|116.41|pekin
Singapore|1.35|103.82|singapur
Sydney|-33.87|151.21
Stockholm|59.33|18.07
Oslo|59.91|10.75
Copenhagen|55.68|12.57|kopenhag
Zurich|47.38|8.54|zürih|zürich
Warsaw|52.23|21.01|varşova
Prague|50.08|14.44|prag
Budapest|47.50|19.04
Lisbon|38.72|-9.14|lizbon
Dublin|53.35|-6.26
São Paulo|-23.55|-46.63|sao paulo
Mexico City|19.43|-99.13
Mumbai|19.08|72.88
Delhi|28.61|77.21|new delhi
Bengaluru|12.97|77.59|bangalore
"""
_COUNTRIES = """
Türkiye|39.0|35.0|turkey|turkiye|tr
Germany|51.2|10.4|almanya|deutschland
United States|39.8|-98.6|usa|us|abd|amerika
United Kingdom|54.0|-2.0|uk|ingiltere|england
France|46.6|2.2|fransa
Netherlands|52.1|5.3|hollanda|nederland
Azerbaijan|40.1|47.6|azerbaycan
"""


def _table() -> dict[str, dict]:
    table: dict[str, dict] = {}
    for block, level, alt in ((_CITIES, "settlement", 30_000), (_COUNTRIES, "country", 1_500_000)):
        for line in block.strip().splitlines():
            name, lat, lon, *aliases = line.split("|")
            entry = {"name": name, "lat": float(lat), "lon": float(lon), "level": level, "altitude_m": alt}
            for a in (name, *aliases):
                table.setdefault(normalize(a), entry)
    return table


_TABLE = _table()


def offline(text: str) -> dict | None:
    """Metnin parçalarından ("Kadıköy, İstanbul") listede olan ilk şehri, yoksa ülkeyi bulur."""
    parts = [normalize(p) for p in re.split(r"[,/|;()·•\-–]+", text) if p.strip()]
    hits = [_TABLE[p] for p in parts if p in _TABLE]
    if not hits:
        # Tek kelime eşleşmesinde kısa takma adları (la, us, van…) kullanma: "La Paz" ≠ Los Angeles
        words = normalize(text).split()
        hits = [_TABLE[w] for w in words if len(w) >= 4 and w in _TABLE]
    hits.sort(key=lambda e: e["level"] != "settlement")
    return dict(hits[0]) if hits else None


_lock = threading.Lock()
_last = 0.0
_cache: dict | None = None


def _cache_file():
    return data_dir() / "geocode.json"


def _load() -> dict:
    global _cache
    if _cache is None:
        try:
            _cache = json.loads(_cache_file().read_text(encoding="utf-8"))
        except (OSError, ValueError):
            _cache = {}
    return _cache


def geocode(text: str, session: requests.Session | None = None, timeout: float = 10) -> dict | None:
    """{'name', 'lat', 'lon', 'level', 'altitude_m'} veya bulunamazsa None."""
    global _last
    key = normalize(text)[:120]
    if not key:
        return None
    local = offline(text)
    if local:
        return local
    with _lock:
        cache = _load()
        if key in cache:
            return cache[key]
        s = session or requests.Session()
        result = None
        for level, alt in LEVELS:
            wait = 1.1 - (time.monotonic() - _last)
            if wait > 0:
                time.sleep(wait)
            _last = time.monotonic()
            r = s.get(NOMINATIM, timeout=timeout, headers={"User-Agent": USER_AGENT},
                      params={"q": text[:200], "format": "jsonv2", "limit": 1, "featureType": level,
                              "accept-language": "tr,en"})
            r.raise_for_status()
            hits = r.json()
            if hits:
                h = hits[0]
                result = {"name": h.get("name") or h.get("display_name", "").split(",")[0],
                          "lat": round(float(h["lat"]), 2), "lon": round(float(h["lon"]), 2),
                          "level": level, "altitude_m": alt}
                break
        cache[key] = result
        try:
            _cache_file().write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass
        return result
