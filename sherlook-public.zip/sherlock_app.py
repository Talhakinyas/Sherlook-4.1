"""Masaüstü paketinin (Sherlook.exe) giriş noktası: web arayüzünü başlatıp tarayıcıyı açar."""

import sys

from sherlock.web import main

if __name__ == "__main__":
    sys.exit(main())
