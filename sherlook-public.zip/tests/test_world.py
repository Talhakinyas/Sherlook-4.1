import io
import os
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import MagicMock, patch

from sherlock.analysis import analyze
from sherlock.geocode import geocode, offline
from sherlock.gev import NODE_OK, _safe_extract, enable_workspace_mode


class GeocodeTests(unittest.TestCase):
    def test_offline_city_level(self):
        self.assertEqual(offline("Kadıköy, İstanbul")["name"], "İstanbul")
        self.assertEqual(offline("ANKARA / TÜRKİYE")["name"], "Ankara")
        self.assertEqual(offline("Antep")["name"], "Gaziantep")
        self.assertEqual(offline("Türkiye")["level"], "country")
        self.assertIsNone(offline("La Paz"))  # kısa takma ad (la) yanlış eşleşmemeli

    def test_online_fallback_rounds_and_caches(self):
        with tempfile.TemporaryDirectory() as d, patch.dict(os.environ, {"SHERLOCK_DATA": d}), \
                patch("sherlock.geocode._cache", None):
            r = MagicMock(); r.json.return_value = [{"name": "Reykjavík", "lat": "64.1466123", "lon": "-21.9426"}]
            s = MagicMock(); s.get.return_value = r
            g = geocode("Reykjavík", session=s)
            self.assertEqual((g["lat"], g["lon"], g["level"]), (64.15, -21.94, "settlement"))
            self.assertEqual(s.get.call_args.kwargs["params"]["featureType"], "settlement")
            geocode("Reykjavík", session=s)
            self.assertEqual(s.get.call_count, 1)  # ikinci sorgu önbellekten


class AnalysisLocationTests(unittest.TestCase):
    def test_locations_grouped(self):
        rows = [{"site": s, "username": "x", "url": "u", "status": "bulundu",
                 "profile": {"location": loc, "links": [], "page_links": [], "emails": []}}
                for s, loc in (("A", "İstanbul"), ("B", "istanbul"), ("C", "Ankara"))]
        locs = analyze(rows, {})["locations"]
        self.assertEqual([(l["text"], len(l["via"])) for l in locs], [("İstanbul", 2), ("Ankara", 1)])


class GevTests(unittest.TestCase):
    def test_workspace_patch_is_repeatable(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            script = root / "src" / "app" / "embed.js"
            css = root / "src" / "ui" / "styles" / "embed.css"
            entry = root / "style.css"
            script.parent.mkdir(parents=True)
            css.parent.mkdir(parents=True)
            entry.write_text("@import './src/ui/styles/embed.css';\n", encoding="utf-8")
            script.write_text("  windowRef.document.body.classList.add('ui-embed');\n"
                              "  shell.setCleanView?.(true);", encoding="utf-8")
            css.write_text("body.ui-embed #clean-view-exit,\n"
                           "body.ui-embed #command-dock { display: none; }", encoding="utf-8")
            self.assertTrue(enable_workspace_mode(root))
            first = (script.read_text(encoding="utf-8"), css.read_text(encoding="utf-8"))
            self.assertTrue(enable_workspace_mode(root))
            self.assertEqual(first, (script.read_text(encoding="utf-8"), css.read_text(encoding="utf-8")))
            self.assertIn("shell.setCleanView?.(!workspace)", first[0])
            self.assertIn("body.ui-embed:not(.ui-sherlock-workspace)", first[1])
            self.assertEqual(entry.read_text(encoding="utf-8").count("sherlock-theme.css"), 1)
            self.assertIn("Sherlock Atlas", (css.parent / "sherlock-theme.css").read_text(encoding="utf-8"))

    def test_node_versions(self):
        self.assertTrue(NODE_OK((24, 22, 2)))
        self.assertTrue(NODE_OK((26, 0, 0)))
        self.assertFalse(NODE_OK((22, 22, 0)))
        self.assertFalse(NODE_OK((24, 13, 9)))
        self.assertFalse(NODE_OK((25, 1, 0)))

    def _zip(self, names):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            for n in names:
                z.writestr(n, "x")
        buf.seek(0)
        return zipfile.ZipFile(buf)

    def test_safe_extract_blocks_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            _safe_extract(self._zip(["gev-main/package.json"]), Path(d))
            self.assertTrue((Path(d) / "gev-main" / "package.json").exists())
            for bad in ("../kaçak.txt", "/etc/kaçak", "a/../../kaçak"):
                with self.assertRaises(ValueError):
                    _safe_extract(self._zip([bad]), Path(d))

    def test_web_endpoints(self):
        from sherlock.web import app
        c = app.test_client()
        st = c.get("/api/gev").json
        for k in ("running", "installed", "phase", "node", "url", "workspace_ready"):
            self.assertIn(k, st)
        self.assertEqual(c.post("/api/gev/sil").status_code, 404)
        self.assertEqual(c.post("/api/gev/start", headers={"Origin": "http://evil.example"}).status_code, 403)
        self.assertEqual(c.get("/api/geocode?q=Bursa").json["result"]["name"], "Bursa")


if __name__ == "__main__":
    unittest.main()
