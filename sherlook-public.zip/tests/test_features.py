import io
import os
import tempfile
import unittest
from unittest.mock import MagicMock

from PIL import Image, ImageDraw

from sherlock.analysis import analyze, diff, match_profile_url, site_patterns
from sherlock.core import load_sites
from sherlock.emailcheck import suggest_usernames
from sherlock.profile import avatar_hash, clean, from_html, hamming
from sherlock.report import render

SITES = {
    "A": {"url": "https://a.example/{}", "errorType": "status_code"},
    "B": {"url": "https://b.example/u/{}", "errorType": "status_code"},
    "C": {"url": "https://c.example/@{}", "errorType": "status_code"},
}


def res(site, user, status="bulundu", **profile):
    return {"site": site, "username": user, "url": SITES[site]["url"].format(user), "status": status,
            "profile": ({"links": [], "page_links": [], "emails": [], **profile} if profile else None)}


class AnalysisTests(unittest.TestCase):
    def test_scores_links_and_photos(self):
        rows = [
            res("A", "ali", name="Ali Veli", avatar_hash="f0f0f0f0f0f0f0f0", links=["https://b.example/u/ali_v"]),
            res("B", "ali_v", name="Ali Veli", avatar_hash="f0f0f0f0f0f0f0f1", emails=["ali@x.com"],
                links=["https://c.example/@aliart"]),
            res("C", "ali", name="Başka Biri"),
            res("A", "nope", status="yok"),
        ]
        a = analyze(rows, SITES, {"name": "Ali Veli", "usernames": ["ali", "ali_v"]})
        s = {k: v["score"] for k, v in a["scores"].items()}
        self.assertGreaterEqual(s["A|ali"], 80)
        self.assertGreaterEqual(s["B|ali_v"], 80)
        self.assertLess(s["C|ali"], 30)
        self.assertEqual(a["avatar_groups"], [["A|ali", "B|ali_v"]] if a["avatar_groups"][0][0] == "A|ali" else [["B|ali_v", "A|ali"]])
        self.assertEqual([(e["from"], e["to"]) for e in a["edges"]], [("A|ali", "B|ali_v")])
        self.assertEqual([(d["site"], d["username"]) for d in a["discovered"]], [("C", "aliart")])
        self.assertEqual(a["emails"][0]["email"], "ali@x.com")

    def test_real_site_patterns(self):
        p = site_patterns(load_sites())
        self.assertEqual(match_profile_url("https://twitter.com/jack", p), ("Twitter / X", "jack"))
        self.assertEqual(match_profile_url("https://www.instagram.com/natgeo/", p), ("Instagram", "natgeo"))
        self.assertIsNone(match_profile_url("https://github.com/login", p))
        self.assertEqual(match_profile_url("https://news.ycombinator.com/user?id=pg", p), ("Hacker News", "pg"))

    def test_diff_ignores_errors(self):
        before = [res("A", "x"), res("B", "x")]
        after = [res("A", "x"), res("B", "x", status="hata"), res("C", "x")]
        self.assertEqual(diff(before, after), {"new": ["C|x"], "gone": []})


class ProfileTests(unittest.TestCase):
    def test_from_html(self):
        html = ('<html><head><title>T</title><meta property="og:title" content="Ali Veli">'
                '<meta property="og:description" content="bio https://ali.dev">'
                '<meta property="og:image" content="/p.png"></head>'
                '<body><a href="https://other.com/x">x</a><a href="https://a.example/in">i</a></body></html>')
        d = from_html(html, "https://a.example/ali")
        self.assertEqual(d["name"], "Ali Veli")
        self.assertEqual(d["avatar"], "https://a.example/p.png")
        self.assertEqual(d["links"], ["https://ali.dev"])
        self.assertEqual(d["page_links"], ["https://other.com/x"])

    def test_clean(self):
        self.assertEqual(clean("<p>a &amp; b</p><p>c</p>"), "a & b\nc")

    def _png(self, draw):
        im = Image.new("RGB", (64, 64), "white")
        draw(ImageDraw.Draw(im))
        buf = io.BytesIO(); im.save(buf, "PNG")
        r = MagicMock(ok=True, headers={"Content-Type": "image/png"})
        r.raw.read.return_value = buf.getvalue()
        s = MagicMock(); s.get.return_value = r
        return s

    def test_avatar_hash_similarity(self):
        a = avatar_hash(self._png(lambda d: d.ellipse((5, 5, 50, 50), fill="red")), "u", 5)
        b = avatar_hash(self._png(lambda d: d.ellipse((6, 5, 51, 50), fill="red")), "u", 5)
        c = avatar_hash(self._png(lambda d: d.polygon([(64, 0), (64, 64), (0, 64)], fill="blue")), "u", 5)
        self.assertLessEqual(hamming(a, b), 10)
        self.assertGreater(hamming(a, c), 10)
        self.assertIsNone(avatar_hash(self._png(lambda d: None), "u", 5))  # boş resim


class MiscTests(unittest.TestCase):
    def test_email_suggestions(self):
        self.assertEqual(suggest_usernames("Ahmet.Yilmaz95+spam@gmail.com")[:4],
                         ["ahmet.yilmaz95", "ahmetyilmaz95", "ahmet.yilmaz", "ahmetyilmaz"])

    def test_report_escapes(self):
        rows = [res("A", "x", name="<script>alert(1)</script>", bio="b")]
        html = render({"title": "<b>t</b>", "created": 0, "params": {}, "results": rows,
                       "analysis": analyze(rows, SITES), "diff": None})
        self.assertNotIn("<script>alert", html)
        self.assertIn("&lt;b&gt;t&lt;/b&gt;", html)


class StorageAndWebTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        os.environ["SHERLOCK_DATA"] = self.tmp.name

    def tearDown(self):
        os.environ.pop("SHERLOCK_DATA", None)
        self.tmp.cleanup()

    def test_save_and_diff(self):
        from sherlock import storage
        p = {"usernames": ["x"]}
        first = storage.save_run(p, [res("A", "x")], {})
        self.assertIsNone(first["diff"])
        second = storage.save_run(p, [res("A", "x"), res("B", "x")], {})
        self.assertEqual(second["diff"]["new"], ["B|x"])
        cases = storage.list_cases()
        self.assertEqual((len(cases), cases[0]["runs"], cases[0]["found"]), (1, 2, 2))
        storage.set_note(first["case_id"], "not")
        self.assertEqual(storage.get_run(second["run_id"])["note"], "not")
        storage.delete_case(first["case_id"])
        self.assertEqual(storage.list_cases(), [])

    def test_web_guards(self):
        from sherlock.web import app
        c = app.test_client()
        self.assertEqual(c.get("/api/cases").status_code, 200)
        self.assertEqual(c.get("/api/cases", headers={"Origin": "http://evil.example"}).status_code, 403)
        self.assertEqual(c.get("/api/cases", headers={"Host": "evil.example"}).status_code, 403)
        self.assertEqual(c.get("/api/search?username=x&proxy=nope").status_code, 400)
        self.assertEqual(c.post("/api/email", json={"email": "bad"}).json["valid"], False)
        self.assertIn("ahmetyilmaz", c.get("/api/variants?name=Ahmet+Yılmaz").json["variants"])


if __name__ == "__main__":
    unittest.main()
