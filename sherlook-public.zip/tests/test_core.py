import unittest
from unittest.mock import MagicMock

from sherlock.core import Status, check_site
from sherlock.variants import generate, normalize


def fake_session(status=200, text="", url=None):
    resp = MagicMock(status_code=status, text=text, url=url or "https://x/u")
    resp.ok = 200 <= status < 400
    s = MagicMock()
    s.get.return_value = resp
    return s


class CheckSiteTests(unittest.TestCase):
    def test_status_code_found(self):
        r = check_site(fake_session(200), "S", {"url": "https://s/{}", "errorType": "status_code"}, "bob", 5)
        self.assertIs(r.status, Status.FOUND)
        self.assertEqual(r.url, "https://s/bob")

    def test_status_code_not_found(self):
        r = check_site(fake_session(404), "S", {"url": "https://s/{}", "errorType": "status_code"}, "bob", 5)
        self.assertIs(r.status, Status.NOT_FOUND)

    def test_blocked_is_error_not_absent(self):
        r = check_site(fake_session(429), "S", {"url": "https://s/{}", "errorType": "status_code"}, "bob", 5)
        self.assertIs(r.status, Status.ERROR)

    def test_message(self):
        info = {"url": "https://s/{}", "errorType": "message", "errorMsg": "No such user"}
        self.assertIs(check_site(fake_session(200, "No such user"), "S", info, "bob", 5).status, Status.NOT_FOUND)
        self.assertIs(check_site(fake_session(200, "profile"), "S", info, "bob", 5).status, Status.FOUND)

    def test_response_url(self):
        info = {"url": "https://s/{}", "errorType": "response_url", "errorUrl": "https://s/"}
        self.assertIs(check_site(fake_session(200, url="https://s/"), "S", info, "bob", 5).status, Status.NOT_FOUND)
        self.assertIs(check_site(fake_session(200, url="https://s/bob"), "S", info, "bob", 5).status, Status.FOUND)

    def test_regex_illegal(self):
        info = {"url": "https://s/{}", "errorType": "status_code", "regexCheck": "^[a-z]+$"}
        s = fake_session()
        self.assertIs(check_site(s, "S", info, "bad name!", 5).status, Status.ILLEGAL)
        s.get.assert_not_called()

    def test_probe_url_used(self):
        s = fake_session()
        check_site(s, "S", {"url": "https://s/{}", "probeUrl": "https://api.s/{}", "errorType": "status_code"}, "bob", 5)
        self.assertEqual(s.get.call_args[0][0], "https://api.s/bob")

    def test_challenge_page_is_error(self):
        page = "<html><head><title>Client Challenge</title></head></html>"
        r = check_site(fake_session(200, page), "S", {"url": "https://s/{}", "errorType": "status_code"}, "bob", 5)
        self.assertIs(r.status, Status.ERROR)


class VariantTests(unittest.TestCase):
    def test_normalize_turkish(self):
        self.assertEqual(normalize("İSMAİL Işık Çağrı Öğüt Şen"), "ismail isik cagri ogut sen")

    def test_full_name_order_and_content(self):
        v = generate("Ahmet Yılmaz", year=1995)
        self.assertEqual(v[0], "ahmetyilmaz")
        for x in ("ahmet.yilmaz", "ahmet_yilmaz", "ayilmaz", "yilmazahmet", "ahmetyilmaz95", "ahmetyilmaz1995"):
            self.assertIn(x, v)
        self.assertEqual(len(v), len(set(v)))

    def test_nickname_first(self):
        self.assertEqual(generate("Mehmet Ali Işık", nickname="Memo")[0], "memo")
        self.assertIn("mehmetaliisik", generate("Mehmet Ali Işık"))

    def test_single_word_variants(self):
        v = generate("torvalds")
        self.assertEqual(v[0], "torvalds")
        self.assertIn("realtorvalds", v)
        self.assertIn("torvalds_official", v)

    def test_limits_and_validity(self):
        self.assertEqual(len(generate("Ahmet Yılmaz", year=1995, extras=["34"], limit=10)), 10)
        self.assertEqual(generate("  !!  "), [])
        for x in generate("A B C", year="1990"):
            self.assertRegex(x, r"^[a-z0-9][a-z0-9._-]{2,29}$")


if __name__ == "__main__":
    unittest.main()
