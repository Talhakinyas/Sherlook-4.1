import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';

const listeners = new Map();
const note = { textContent: '' };
const host = {
  hidden: true,
  innerHTML: '',
  setAttribute() {},
  querySelector(selector) {
    return selector === 'button' ? { addEventListener() {} } : note;
  },
};
const document = {
  body: { append() {} },
  head: { append() {} },
  createElement(tag) { return tag === 'aside' ? host : { textContent: '' }; },
  addEventListener() {},
};
const store = { selectedEntityId: null, entities: new Map() };
const window = {
  __gevContextStore: store,
  addEventListener(type, listener) { listeners.set(type, listener); },
};
runInNewContext(readFileSync(new URL('../sherlock/static/gev-inspector.js', import.meta.url), 'utf8'), {
  document, window, requestAnimationFrame: callback => callback(),
});

store.selectedEntityId = 'fire-1';
store.entities.set('fire-1', {
  id: 'fire-1', layerId: 'fires', layerName: 'Active fires', label: 'Fire 1',
  source: 'NASA FIRMS', latitude: 40.1, longitude: 29.2,
  properties: { frp: 12, confidence: 'high' },
});
listeners.get('gev:entity-selected')();
assert.equal(host.hidden, false);
assert.match(host.innerHTML, /NASA FIRMS/);
assert.match(host.innerHTML, /40\.100°/);
assert.match(host.innerHTML, /Yangın gücü/);

store.selectedEntityId = 'sat-1';
store.entities.set('sat-1', {
  id: 'sat-1', layerId: 'satellites', label: 'Test satellite',
  properties: { noradId: '12345', altitude: '500 km' },
});
listeners.get('gev:awareness-subject-selected')();
assert.match(host.innerHTML, /Test satellite/);
assert.match(note.textContent, /fotoğrafı doğrulanamadı/);

store.selectedEntityId = null;
listeners.get('gev:entity-selection-cleared')();
assert.equal(host.hidden, true);
console.log('Sherlook inspector selection checks passed');
